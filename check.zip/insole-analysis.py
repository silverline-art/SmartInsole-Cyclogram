#!/usr/bin/env python3
"""
Smart Insole Gait Analysis Module

Anatomically grounded gait phase detection and cyclogram generation from
synchronized pressure sensor and IMU data.

Architecture:
- InsoleLoader: Data ingestion and preprocessing
- SignalProcessor: Filtering and feature extraction
- GaitPhaseDetector: 8-phase biomechanical detection
- CyclogramGenerator: IMU coordination loop extraction
- ValidationEngine: Anatomical plausibility verification
- InsoleVisualizer: Phase-segmented visualization

Author: Gait Analysis Pipeline
Date: 2025-10-16
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional
from scipy.signal import butter, filtfilt, find_peaks
from scipy.interpolate import interp1d
import argparse
import warnings
warnings.filterwarnings('ignore')

# Import enhanced visualizer
try:
    from enhanced_visualizer import EnhancedInsoleVisualizer, PlotConfig
    ENHANCED_VIZ_AVAILABLE = True
except ImportError:
    ENHANCED_VIZ_AVAILABLE = False
    print("Warning: Enhanced visualizer not available")


# ============================================================================
# CONFIGURATION AND DATA STRUCTURES
# ============================================================================

@dataclass
class InsoleConfig:
    """Configuration for insole gait analysis."""

    # Signal processing
    sampling_rate: float = 100.0  # Hz
    filter_cutoff: float = 20.0    # Hz (lowpass for gait dynamics)
    filter_order: int = 4

    # Gait cycle constraints (seconds)
    min_cycle_duration: float = 0.8   # Minimum gait cycle duration
    max_cycle_duration: float = 2.0   # Maximum gait cycle duration
    min_stance_duration: float = 0.5  # Minimum stance phase duration
    min_swing_duration: float = 0.3   # Minimum swing phase duration

    # Phase detection thresholds
    pressure_threshold: float = 0.5    # Normalized pressure for contact detection
    pressure_derivative_threshold: float = 0.1  # For IC detection
    gyro_swing_threshold: float = 50.0  # deg/s for swing detection

    # Validation thresholds
    stance_swing_ratio_min: float = 1.2  # Expected 60:40 = 1.5
    stance_swing_ratio_max: float = 2.0
    bilateral_tolerance: float = 0.15    # 15% duration difference allowed

    # Visualization
    plot_dpi: int = 150
    cyclogram_resolution: int = 100  # Points per gait cycle


@dataclass
class GaitPhase:
    """Single gait phase annotation."""
    phase_name: str          # IC, LR, MSt, TSt, PSw, ISw, MSw, TSw
    leg: str                 # 'left' or 'right'
    start_time: float        # seconds
    end_time: float          # seconds
    start_idx: int           # frame index
    end_idx: int             # frame index
    duration: float          # seconds
    phase_number: int        # 1-8


@dataclass
class GaitCycle:
    """Complete gait cycle with all phases."""
    leg: str
    cycle_id: int
    start_time: float
    end_time: float
    duration: float
    phases: List[GaitPhase]
    stance_duration: float
    swing_duration: float
    stance_swing_ratio: float


@dataclass
class CyclogramData:
    """IMU-based cyclogram for one gait cycle."""
    cycle: GaitCycle
    x_signal: np.ndarray      # e.g., ACC_X
    y_signal: np.ndarray      # e.g., ACC_Y
    x_label: str
    y_label: str
    phase_indices: List[int]  # Phase boundary indices
    phase_labels: List[str]   # Phase names for coloring


@dataclass
class GaitEventRecord:
    """High-precision gait event with sensor zone information."""
    event_type: str          # 'heel_strike', 'mid_stance', 'toe_off'
    leg: str                 # 'left' or 'right'
    event_start: float       # timestamp in seconds
    event_end: float         # timestamp in seconds
    duration: float          # milliseconds
    sensor_source: str       # e.g., 'L_value4', 'R_value2'
    frame_start: int         # frame index
    frame_end: int           # frame index
    confidence: float        # 0.0-1.0


@dataclass
class CalibrationParameters:
    """Self-calibration parameters for adaptive signal processing."""
    # Pressure sensor calibration
    pressure_baseline_left: Dict[str, float] = field(default_factory=dict)
    pressure_baseline_right: Dict[str, float] = field(default_factory=dict)
    pressure_scale_left: Dict[str, float] = field(default_factory=dict)
    pressure_scale_right: Dict[str, float] = field(default_factory=dict)

    # IMU sensor calibration
    acc_mean_left: Dict[str, float] = field(default_factory=dict)
    acc_mean_right: Dict[str, float] = field(default_factory=dict)
    acc_std_left: Dict[str, float] = field(default_factory=dict)
    acc_std_right: Dict[str, float] = field(default_factory=dict)
    gyro_mean_left: Dict[str, float] = field(default_factory=dict)
    gyro_mean_right: Dict[str, float] = field(default_factory=dict)
    gyro_std_left: Dict[str, float] = field(default_factory=dict)
    gyro_std_right: Dict[str, float] = field(default_factory=dict)

    # Adaptive filter parameters
    dominant_frequency_left: float = 1.0
    dominant_frequency_right: float = 1.0
    adaptive_cutoff_left: float = 20.0
    adaptive_cutoff_right: float = 20.0


@dataclass
class ValidationMetrics:
    """Anatomical plausibility validation results."""
    left_right_alternation: bool
    stance_swing_ratio_valid: bool
    bilateral_symmetry_valid: bool
    phase_sequence_valid: bool
    duration_constraints_valid: bool
    overall_valid: bool
    issues: List[str] = field(default_factory=list)


# ============================================================================
# INSOLE DATA LOADER
# ============================================================================

class InsoleLoader:
    """Data ingestion and column detection for smart insole data."""

    def __init__(self, config: InsoleConfig):
        self.config = config

    def load_data(self, csv_path: Path) -> pd.DataFrame:
        """
        Load insole CSV data with automatic header detection.

        Expected columns:
        - timestamp: Time in milliseconds
        - L_value1-4, R_value1-4: Pressure sensors
        - L_ACC_X/Y/Z, R_ACC_X/Y/Z: Accelerometers
        - L_GYRO_X/Y/Z, R_GYRO_X/Y/Z: Gyroscopes
        """
        print(f"Loading insole data from {csv_path}")

        # Read CSV, skip header rows
        df = pd.read_csv(csv_path, skiprows=3)

        # Convert timestamp from ms to seconds
        if 'timestamp' in df.columns:
            df['timestamp'] = df['timestamp'] / 1000.0

        print(f"Loaded {len(df)} samples ({df['timestamp'].iloc[-1]:.1f} seconds)")

        # Verify required columns
        required_cols = self._get_required_columns()
        missing = [col for col in required_cols if col not in df.columns]

        if missing:
            raise ValueError(f"Missing required columns: {missing}")

        return df

    def _get_required_columns(self) -> List[str]:
        """Define required columns for analysis."""
        pressure_cols = [f'L_value{i}' for i in range(1, 5)] + \
                       [f'R_value{i}' for i in range(1, 5)]

        acc_cols = [f'{side}_ACC_{axis}'
                   for side in ['L', 'R']
                   for axis in ['X', 'Y', 'Z']]

        gyro_cols = [f'{side}_GYRO_{axis}'
                    for side in ['L', 'R']
                    for axis in ['X', 'Y', 'Z']]

        return ['timestamp'] + pressure_cols + acc_cols + gyro_cols

    def detect_column_mapping(self, df: pd.DataFrame) -> Dict[str, List[str]]:
        """Create column mapping for left/right sensors."""
        mapping = {
            'left_pressure': [f'L_value{i}' for i in range(1, 5)],
            'right_pressure': [f'R_value{i}' for i in range(1, 5)],
            'left_acc': ['L_ACC_X', 'L_ACC_Y', 'L_ACC_Z'],
            'right_acc': ['R_ACC_X', 'R_ACC_Y', 'R_ACC_Z'],
            'left_gyro': ['L_GYRO_X', 'L_GYRO_Y', 'L_GYRO_Z'],
            'right_gyro': ['R_GYRO_X', 'R_GYRO_Y', 'R_GYRO_Z']
        }
        return mapping


# ============================================================================
# SIGNAL PROCESSOR
# ============================================================================

class SignalProcessor:
    """
    Self-calibrating and adaptive signal filtering for gait analysis.

    Features:
    - Automatic baseline correction and amplitude normalization
    - Spectral analysis for dominant gait frequency detection
    - Adaptive Butterworth filter with dynamic cutoff adjustment
    - Frame-to-frame filter strength adaptation based on signal variance
    """

    def __init__(self, config: InsoleConfig):
        self.config = config
        self.calibration = CalibrationParameters()
        self.is_calibrated = False
        self._design_filter()

    def _design_filter(self, cutoff_freq: Optional[float] = None):
        """
        Design Butterworth lowpass filter.

        Args:
            cutoff_freq: Optional custom cutoff frequency (Hz)
        """
        nyquist = self.config.sampling_rate / 2.0
        cutoff = cutoff_freq if cutoff_freq is not None else self.config.filter_cutoff
        cutoff_normalized = cutoff / nyquist
        self.b, self.a = butter(self.config.filter_order, cutoff_normalized, btype='low')

    def calibrate_signals(self, df: pd.DataFrame, col_map: Dict) -> pd.DataFrame:
        """
        Self-calibrating baseline correction and normalization.

        Pressure Sensors:
        - Baseline offset: 2nd percentile (rest-state bias)
        - Scale factor: 98th percentile - baseline
        - Normalize to [0-1] range

        IMU Sensors:
        - Bias removal: subtract mean
        - Standardization: divide by std

        Args:
            df: Raw sensor dataframe
            col_map: Column mapping for sensors

        Returns:
            Calibrated dataframe
        """
        print("  Performing self-calibration...")

        result = df.copy()

        # Calibrate pressure sensors
        for side in ['left', 'right']:
            side_key = f'{side}_pressure'
            pressure_cols = col_map[side_key]

            for col in pressure_cols:
                signal = df[col].values

                # Estimate baseline (2nd percentile for rest-state)
                baseline = np.percentile(signal, 2)

                # Determine scale factor (98th percentile - baseline)
                p98 = np.percentile(signal, 98)
                scale_factor = p98 - baseline + 1e-6

                # Apply zero-offset correction and normalize to [0-1]
                calibrated = (signal - baseline) / scale_factor
                calibrated = np.clip(calibrated, 0, 1)  # Ensure [0-1] range

                result[col] = calibrated

                # Store calibration parameters
                if side == 'left':
                    self.calibration.pressure_baseline_left[col] = baseline
                    self.calibration.pressure_scale_left[col] = scale_factor
                else:
                    self.calibration.pressure_baseline_right[col] = baseline
                    self.calibration.pressure_scale_right[col] = scale_factor

        # Calibrate IMU sensors (ACC + GYRO)
        for side in ['left', 'right']:
            # Accelerometer
            acc_cols = col_map[f'{side}_acc']
            for col in acc_cols:
                signal = df[col].values

                # Compute mean and std for bias removal and standardization
                mean_val = np.mean(signal)
                std_val = np.std(signal) + 1e-6

                # Apply bias removal and standardization
                calibrated = (signal - mean_val) / std_val

                result[col] = calibrated

                # Store parameters
                if side == 'left':
                    self.calibration.acc_mean_left[col] = mean_val
                    self.calibration.acc_std_left[col] = std_val
                else:
                    self.calibration.acc_mean_right[col] = mean_val
                    self.calibration.acc_std_right[col] = std_val

            # Gyroscope
            gyro_cols = col_map[f'{side}_gyro']
            for col in gyro_cols:
                signal = df[col].values

                mean_val = np.mean(signal)
                std_val = np.std(signal) + 1e-6

                calibrated = (signal - mean_val) / std_val

                result[col] = calibrated

                if side == 'left':
                    self.calibration.gyro_mean_left[col] = mean_val
                    self.calibration.gyro_std_left[col] = std_val
                else:
                    self.calibration.gyro_mean_right[col] = mean_val
                    self.calibration.gyro_std_right[col] = std_val

        # Analyze dominant gait frequency and adapt filter
        self._analyze_and_adapt_filter(result, col_map)

        self.is_calibrated = True
        print(f"  Calibration complete (Left freq: {self.calibration.dominant_frequency_left:.2f} Hz, "
              f"Right freq: {self.calibration.dominant_frequency_right:.2f} Hz)")

        return result

    def _analyze_and_adapt_filter(self, df: pd.DataFrame, col_map: Dict):
        """
        Analyze dominant gait frequency using FFT and adapt filter cutoff.

        Args:
            df: Calibrated dataframe
            col_map: Column mapping
        """
        for side in ['left', 'right']:
            # Use total pressure for spectral analysis
            pressure_cols = col_map[f'{side}_pressure']
            total_pressure = df[pressure_cols].sum(axis=1).values

            # Perform FFT
            dominant_freq = self._analyze_signal_spectrum(total_pressure)

            # Adaptive cutoff: 3× dominant gait frequency, bounded [5-25 Hz]
            adaptive_cutoff = np.clip(3.0 * dominant_freq, 5.0, 25.0)

            # Store parameters
            if side == 'left':
                self.calibration.dominant_frequency_left = dominant_freq
                self.calibration.adaptive_cutoff_left = adaptive_cutoff
            else:
                self.calibration.dominant_frequency_right = dominant_freq
                self.calibration.adaptive_cutoff_right = adaptive_cutoff

    def _analyze_signal_spectrum(self, signal: np.ndarray) -> float:
        """
        Analyze signal spectrum to find dominant gait frequency.

        Args:
            signal: Time-domain signal

        Returns:
            Dominant frequency in Hz
        """
        # Perform FFT
        fft_vals = np.fft.rfft(signal)
        fft_freq = np.fft.rfftfreq(len(signal), 1.0 / self.config.sampling_rate)

        # Compute power spectrum
        power = np.abs(fft_vals) ** 2

        # Find dominant frequency in gait range (0.5-3.0 Hz typical)
        gait_mask = (fft_freq >= 0.5) & (fft_freq <= 3.0)
        if np.any(gait_mask):
            gait_power = power[gait_mask]
            gait_freqs = fft_freq[gait_mask]

            # Find peak frequency
            peak_idx = np.argmax(gait_power)
            dominant_freq = gait_freqs[peak_idx]
        else:
            # Fallback to 1 Hz if no clear peak
            dominant_freq = 1.0

        return dominant_freq

    def filter_signal(self, signal: np.ndarray, adaptive: bool = False,
                     leg: Optional[str] = None) -> np.ndarray:
        """
        Apply lowpass filter with optional adaptive mode.

        Args:
            signal: Input signal
            adaptive: Use adaptive cutoff based on calibration
            leg: Leg identifier ('left' or 'right') for adaptive mode

        Returns:
            Filtered signal
        """
        if adaptive and leg and self.is_calibrated:
            # Use adaptive cutoff frequency
            cutoff = (self.calibration.adaptive_cutoff_left if leg == 'left'
                     else self.calibration.adaptive_cutoff_right)

            # Re-design filter with adaptive cutoff
            nyquist = self.config.sampling_rate / 2.0
            cutoff_normalized = cutoff / nyquist
            b, a = butter(self.config.filter_order, cutoff_normalized, btype='low')

            return filtfilt(b, a, signal)
        else:
            # Use standard filter
            return filtfilt(self.b, self.a, signal)

    def adaptive_filter_with_variance(self, signal: np.ndarray, window_size: int = 30) -> np.ndarray:
        """
        Apply adaptive filtering with frame-to-frame strength adjustment.

        Low variance → stronger filtering (more smoothing)
        High variance → lighter filtering (preserve transitions)

        Args:
            signal: Input signal
            window_size: Rolling window size for variance estimation (samples)

        Returns:
            Adaptively filtered signal
        """
        # Compute rolling variance using exponential moving average
        variance = np.zeros_like(signal)
        alpha = 2.0 / (window_size + 1)  # EMA smoothing factor

        # Initialize with first window variance
        variance[0] = np.var(signal[:window_size]) if len(signal) >= window_size else np.var(signal)

        # Compute exponential moving variance
        for i in range(1, len(signal)):
            start_idx = max(0, i - window_size)
            local_var = np.var(signal[start_idx:i+1])
            variance[i] = alpha * local_var + (1 - alpha) * variance[i-1]

        # Normalize variance to [0-1] range for adaptive weight
        var_normalized = (variance - variance.min()) / (variance.max() - variance.min() + 1e-6)

        # Adaptive filter strength: low variance → strong filter (high weight)
        # Invert so high variance → light filtering
        filter_strength = 1.0 - var_normalized

        # Apply multiple passes with varying filter strengths
        filtered = signal.copy()

        # Light filter pass (preserve details)
        light_cutoff = self.config.filter_cutoff * 1.5  # 30 Hz
        nyquist = self.config.sampling_rate / 2.0
        b_light, a_light = butter(2, light_cutoff / nyquist, btype='low')
        filtered_light = filtfilt(b_light, a_light, signal)

        # Strong filter pass (smooth)
        strong_cutoff = self.config.filter_cutoff * 0.5  # 10 Hz
        b_strong, a_strong = butter(4, strong_cutoff / nyquist, btype='low')
        filtered_strong = filtfilt(b_strong, a_strong, signal)

        # Blend based on local variance
        filtered = filter_strength * filtered_strong + (1 - filter_strength) * filtered_light

        return filtered

    def compute_pressure_features(self, df: pd.DataFrame, col_map: Dict) -> pd.DataFrame:
        """
        Compute pressure-based features with adaptive filtering.

        Features:
        - total_pressure: Sum of all sensors (adaptively filtered)
        - pressure_derivative: Rate of change for IC/TO detection
        - normalized_pressure: Z-scored for adaptive thresholding
        """
        result = df.copy()

        for side in ['left', 'right']:
            pressure_cols = col_map[f'{side}_pressure']

            # Total pressure
            total = df[pressure_cols].sum(axis=1).values

            # Apply adaptive filtering if calibrated
            if self.is_calibrated:
                total_filtered = self.filter_signal(total, adaptive=True, leg=side)
            else:
                total_filtered = self.filter_signal(total)

            result[f'{side}_pressure_total'] = total_filtered

            # Derivative for IC detection
            derivative = np.gradient(total_filtered)
            result[f'{side}_pressure_deriv'] = derivative

            # Normalized pressure
            normalized = (total_filtered - total_filtered.mean()) / (total_filtered.std() + 1e-6)
            result[f'{side}_pressure_norm'] = normalized

        return result

    def compute_imu_features(self, df: pd.DataFrame, col_map: Dict) -> pd.DataFrame:
        """
        Compute IMU-based features for phase detection with adaptive filtering.

        Features:
        - acc_magnitude: sqrt(x^2 + y^2 + z^2) (adaptively filtered)
        - gyro_magnitude: Angular velocity magnitude (adaptively filtered)
        - acc_filtered: Lowpass filtered accelerations
        - gyro_filtered: Lowpass filtered gyroscope
        """
        result = df.copy()

        for side in ['left', 'right']:
            # Accelerometer magnitude
            acc_cols = col_map[f'{side}_acc']
            acc_x, acc_y, acc_z = [df[col].values for col in acc_cols]

            acc_mag = np.sqrt(acc_x**2 + acc_y**2 + acc_z**2)

            # Apply adaptive filtering if calibrated
            if self.is_calibrated:
                result[f'{side}_acc_mag'] = self.filter_signal(acc_mag, adaptive=True, leg=side)
            else:
                result[f'{side}_acc_mag'] = self.filter_signal(acc_mag)

            # Filter individual axes
            for col in acc_cols:
                if self.is_calibrated:
                    result[f'{col}_filt'] = self.filter_signal(df[col].values, adaptive=True, leg=side)
                else:
                    result[f'{col}_filt'] = self.filter_signal(df[col].values)

            # Gyroscope magnitude
            gyro_cols = col_map[f'{side}_gyro']
            gyro_x, gyro_y, gyro_z = [df[col].values for col in gyro_cols]

            gyro_mag = np.sqrt(gyro_x**2 + gyro_y**2 + gyro_z**2)

            # Apply adaptive filtering if calibrated
            if self.is_calibrated:
                result[f'{side}_gyro_mag'] = self.filter_signal(gyro_mag, adaptive=True, leg=side)
            else:
                result[f'{side}_gyro_mag'] = self.filter_signal(gyro_mag)

            # Filter individual axes
            for col in gyro_cols:
                if self.is_calibrated:
                    result[f'{col}_filt'] = self.filter_signal(df[col].values, adaptive=True, leg=side)
                else:
                    result[f'{col}_filt'] = self.filter_signal(df[col].values)

        return result


# ============================================================================
# PRESSURE SENSOR ZONE DETECTOR
# ============================================================================

class PressureSensorZoneDetector:
    """
    High-precision gait event detection using anatomical sensor zone mapping.

    Sensor Zone Mapping:
    - Hindfoot: Sensor 4 (heel region)
    - Midfoot: Sensors 1 & 3 (arch region)
    - Forefoot: Sensor 2 (toe region)

    Multi-sensor Logic:
    - Heel Strike: Hindfoot (sensor 4) first activation
    - Mid-Stance: Midfoot (sensors 1 & 3) active, forefoot off
    - Toe-Off: Forefoot (sensor 2) final release
    """

    def __init__(self, config: InsoleConfig):
        self.config = config
        # Calibrated activation threshold (% of max pressure)
        self.activation_threshold = 0.1  # 10% of signal max
        # Minimum duration for valid event (milliseconds)
        self.min_event_duration = 20.0  # 20ms

    def detect_heel_strike_events(self, df: pd.DataFrame, leg: str) -> List[GaitEventRecord]:
        """
        Detect heel strike events from hindfoot sensor (sensor 4).

        Biomechanical signature: Sharp rise in sensor 4 pressure.
        """
        leg_prefix = 'L' if leg == 'left' else 'R'
        sensor_col = f'{leg_prefix}_value4'  # Hindfoot sensor

        pressure = df[sensor_col].values
        timestamps = df['timestamp'].values

        # Adaptive threshold based on signal statistics
        threshold = self.activation_threshold * np.max(pressure)

        events = []
        in_contact = False
        contact_start_idx = 0

        for i in range(1, len(pressure)):
            if not in_contact and pressure[i] > threshold and pressure[i] > pressure[i-1]:
                # Contact initiated
                in_contact = True
                contact_start_idx = i
            elif in_contact and pressure[i] < threshold:
                # Contact released
                contact_end_idx = i
                duration_ms = (timestamps[contact_end_idx] - timestamps[contact_start_idx]) * 1000

                if duration_ms >= self.min_event_duration:
                    # Compute confidence based on pressure magnitude
                    peak_pressure = np.max(pressure[contact_start_idx:contact_end_idx])
                    confidence = min(1.0, peak_pressure / (np.max(pressure) + 1e-6))

                    event = GaitEventRecord(
                        event_type='heel_strike',
                        leg=leg,
                        event_start=timestamps[contact_start_idx],
                        event_end=timestamps[contact_end_idx],
                        duration=duration_ms,
                        sensor_source=sensor_col,
                        frame_start=contact_start_idx,
                        frame_end=contact_end_idx,
                        confidence=confidence
                    )
                    events.append(event)

                in_contact = False

        return events

    def detect_mid_stance_events(self, df: pd.DataFrame, leg: str) -> List[GaitEventRecord]:
        """
        Detect mid-stance events: midfoot (sensors 1 & 3) active, forefoot off.

        Biomechanical signature: Weight transfer to midfoot region.
        """
        leg_prefix = 'L' if leg == 'left' else 'R'
        midfoot_1 = df[f'{leg_prefix}_value1'].values
        midfoot_3 = df[f'{leg_prefix}_value3'].values
        forefoot = df[f'{leg_prefix}_value2'].values
        timestamps = df['timestamp'].values

        # Combined midfoot pressure
        midfoot_total = midfoot_1 + midfoot_3

        # Adaptive thresholds
        midfoot_threshold = self.activation_threshold * np.max(midfoot_total)
        forefoot_threshold = self.activation_threshold * np.max(forefoot) * 0.5  # Lower threshold for "off"

        events = []
        in_midstance = False
        stance_start_idx = 0

        for i in range(1, len(midfoot_total)):
            # Mid-stance condition: midfoot active AND forefoot off
            midfoot_active = midfoot_total[i] > midfoot_threshold
            forefoot_off = forefoot[i] < forefoot_threshold

            if not in_midstance and midfoot_active and forefoot_off:
                # Mid-stance initiated
                in_midstance = True
                stance_start_idx = i
            elif in_midstance and (not midfoot_active or not forefoot_off):
                # Mid-stance ended
                stance_end_idx = i
                duration_ms = (timestamps[stance_end_idx] - timestamps[stance_start_idx]) * 1000

                if duration_ms >= self.min_event_duration:
                    peak_midfoot = np.max(midfoot_total[stance_start_idx:stance_end_idx])
                    confidence = min(1.0, peak_midfoot / (np.max(midfoot_total) + 1e-6))

                    event = GaitEventRecord(
                        event_type='mid_stance',
                        leg=leg,
                        event_start=timestamps[stance_start_idx],
                        event_end=timestamps[stance_end_idx],
                        duration=duration_ms,
                        sensor_source=f'{leg_prefix}_value1,{leg_prefix}_value3',
                        frame_start=stance_start_idx,
                        frame_end=stance_end_idx,
                        confidence=confidence
                    )
                    events.append(event)

                in_midstance = False

        return events

    def detect_toe_off_events(self, df: pd.DataFrame, leg: str) -> List[GaitEventRecord]:
        """
        Detect toe-off events from forefoot sensor (sensor 2).

        Biomechanical signature: Final release of forefoot pressure.
        """
        leg_prefix = 'L' if leg == 'left' else 'R'
        sensor_col = f'{leg_prefix}_value2'  # Forefoot sensor

        pressure = df[sensor_col].values
        timestamps = df['timestamp'].values

        # Adaptive threshold
        threshold = self.activation_threshold * np.max(pressure)

        events = []
        in_contact = False
        contact_start_idx = 0

        for i in range(1, len(pressure)):
            if not in_contact and pressure[i] > threshold:
                # Contact initiated
                in_contact = True
                contact_start_idx = i
            elif in_contact and pressure[i] < threshold and pressure[i] < pressure[i-1]:
                # Contact released (toe-off)
                contact_end_idx = i
                duration_ms = (timestamps[contact_end_idx] - timestamps[contact_start_idx]) * 1000

                if duration_ms >= self.min_event_duration:
                    peak_pressure = np.max(pressure[contact_start_idx:contact_end_idx])
                    confidence = min(1.0, peak_pressure / (np.max(pressure) + 1e-6))

                    event = GaitEventRecord(
                        event_type='toe_off',
                        leg=leg,
                        event_start=timestamps[contact_start_idx],
                        event_end=timestamps[contact_end_idx],
                        duration=duration_ms,
                        sensor_source=sensor_col,
                        frame_start=contact_start_idx,
                        frame_end=contact_end_idx,
                        confidence=confidence
                    )
                    events.append(event)

                in_contact = False

        return events

    def detect_all_events(self, df: pd.DataFrame, leg: str) -> Dict[str, List[GaitEventRecord]]:
        """
        Detect all gait events for one leg.

        Returns:
            Dictionary with keys: 'heel_strike', 'mid_stance', 'toe_off'
        """
        return {
            'heel_strike': self.detect_heel_strike_events(df, leg),
            'mid_stance': self.detect_mid_stance_events(df, leg),
            'toe_off': self.detect_toe_off_events(df, leg)
        }


# ============================================================================
# GAIT PHASE DETECTOR
# ============================================================================

class GaitPhaseDetector:
    """
    Anatomically grounded 8-phase gait detection using pressure + IMU fusion.

    Phases (Perry's gait model):
    1. Initial Contact (IC): Heel strike
    2. Loading Response (LR): Weight acceptance
    3. Mid-Stance (MSt): Single limb support
    4. Terminal Stance (TSt): Heel rise
    5. Pre-Swing (PSw): Toe-off preparation
    6. Initial Swing (ISw): Leg acceleration
    7. Mid-Swing (MSw): Leg advancement
    8. Terminal Swing (TSw): Leg deceleration
    """

    def __init__(self, config: InsoleConfig, precision_detector: Optional[PressureSensorZoneDetector] = None):
        self.config = config
        self.precision_detector = precision_detector
        self.precision_events = None  # Cache for detected events

    def detect_gait_cycles(self, df: pd.DataFrame, leg: str) -> List[GaitCycle]:
        """
        Detect complete gait cycles (IC to IC) for one leg.

        Returns:
            List of GaitCycle objects with phase annotations
        """
        print(f"\nDetecting gait cycles for {leg} leg...")

        timestamps = df['timestamp'].values

        # Use precision detector if available
        if self.precision_detector is not None:
            print(f"  Using high-precision sensor zone detection...")
            if self.precision_events is None:
                self.precision_events = self.precision_detector.detect_all_events(df, leg)

            heel_strikes = self.precision_events['heel_strike']
            ic_indices = [event.frame_start for event in heel_strikes]
            print(f"  Found {len(ic_indices)} precision heel strikes (avg confidence: {np.mean([e.confidence for e in heel_strikes]):.2f})")
        else:
            # Fallback to original detection
            pressure = df[f'{leg}_pressure_total'].values
            pressure_deriv = df[f'{leg}_pressure_deriv'].values
            ic_indices = self._detect_initial_contacts(pressure, pressure_deriv)
            print(f"  Found {len(ic_indices)} initial contacts (legacy method)")

        # Build gait cycles between consecutive ICs
        cycles = []
        for i in range(len(ic_indices) - 1):
            start_idx = ic_indices[i]
            end_idx = ic_indices[i + 1]

            start_time = timestamps[start_idx]
            end_time = timestamps[end_idx]
            duration = end_time - start_time

            # Validate duration
            if not (self.config.min_cycle_duration <= duration <= self.config.max_cycle_duration):
                continue

            # Detect phases within this cycle
            phases = self._detect_phases_in_cycle(
                df, leg, start_idx, end_idx, start_time
            )

            # Skip cycles with invalid phase detection
            if not phases or len(phases) != 8:
                continue

            # Compute stance and swing durations
            stance_phases = [p for p in phases if p.phase_number <= 5]  # IC to PSw
            swing_phases = [p for p in phases if p.phase_number > 5]     # ISw to TSw

            stance_duration = sum(p.duration for p in stance_phases)
            swing_duration = sum(p.duration for p in swing_phases)

            ratio = stance_duration / (swing_duration + 1e-6)

            cycle = GaitCycle(
                leg=leg,
                cycle_id=len(cycles) + 1,
                start_time=start_time,
                end_time=end_time,
                duration=duration,
                phases=phases,
                stance_duration=stance_duration,
                swing_duration=swing_duration,
                stance_swing_ratio=ratio
            )

            cycles.append(cycle)

        print(f"  Extracted {len(cycles)} valid gait cycles")
        return cycles

    def _detect_initial_contacts(self, pressure: np.ndarray,
                                 pressure_deriv: np.ndarray) -> List[int]:
        """
        Detect initial contact (heel strike) events.

        Biomechanical signature: Sharp pressure rise
        """
        # Find peaks in pressure derivative (rapid increase)
        ic_candidates, _ = find_peaks(
            pressure_deriv,
            height=self.config.pressure_derivative_threshold,
            distance=int(self.config.sampling_rate * 0.5)  # Min 0.5s between ICs
        )

        # Filter by pressure level (must be significant contact)
        ic_indices = [idx for idx in ic_candidates
                     if pressure[idx] > self.config.pressure_threshold]

        return ic_indices

    def _detect_phases_in_cycle(self, df: pd.DataFrame, leg: str,
                                start_idx: int, end_idx: int,
                                start_time: float) -> List[GaitPhase]:
        """
        Detect all 8 gait phases using event-anchored biomechanical segmentation.

        Uses high-precision pressure sensor events instead of time-based heuristics:
        - IC (Initial Contact) = heel_strike.event_start
        - Mid-Stance = mid_stance events
        - TO (Toe-Off) = toe_off.event_end
        """
        cycle_data = df.iloc[start_idx:end_idx].copy()
        timestamps = cycle_data['timestamp'].values

        # Use event-anchored detection if precision detector available
        if self.precision_detector is not None and self.precision_events is not None:
            return self._detect_phases_event_anchored(
                df, leg, start_idx, end_idx, timestamps
            )
        else:
            # Fallback to legacy heuristic detection
            return self._detect_phases_heuristic(
                df, leg, start_idx, end_idx, timestamps
            )

    def _detect_phases_event_anchored(self, df: pd.DataFrame, leg: str,
                                      start_idx: int, end_idx: int,
                                      timestamps: np.ndarray) -> List[GaitPhase]:
        """
        Event-anchored phase detection using precision pressure sensor events.

        Phase Segmentation:
        - IC: Heel strike start
        - LR: IC → mid-stance start
        - MSt: mid-stance start → end
        - TSt: mid-stance end → 90% of stance
        - PSw: 90% stance → toe-off
        - ISw, MSw, TSw: Divide swing into thirds
        """
        # 1. Get high-precision events within this cycle window
        events = {
            event_type: [e for e in self.precision_events[event_type]
                        if start_idx <= e.frame_start <= end_idx]
            for event_type in ['heel_strike', 'mid_stance', 'toe_off']
        }

        ic_event = events['heel_strike'][0] if events['heel_strike'] else None
        ms_events = events['mid_stance'] if events['mid_stance'] else []
        to_event = events['toe_off'][0] if events['toe_off'] else None

        # 2. Validate event order
        if not ic_event or not to_event:
            # Missing critical events - fall back to heuristic
            return self._detect_phases_heuristic(df, leg, start_idx, end_idx, timestamps)

        if ic_event.frame_start >= to_event.frame_start:
            # Invalid event order - skip cycle
            return []

        # 3. Extract key timestamps
        ic_t = ic_event.event_start
        to_t = to_event.event_end
        next_ic_t = timestamps[-1]

        # Find the primary mid-stance event (longest duration or highest confidence)
        ms_event = None
        if ms_events:
            ms_event = max(ms_events, key=lambda e: e.duration * e.confidence)

        # 4. Build stance phases using real biomechanical events
        phases = []

        # Phase 1: Initial Contact (brief impact phase)
        ic_duration = 0.05  # 50ms typical IC duration
        ic_end_t = min(ic_t + ic_duration, timestamps[-1])
        ic_end_idx = np.argmin(np.abs(df['timestamp'].values - ic_end_t))

        phases.append(GaitPhase(
            phase_name='Initial Contact',
            leg=leg,
            start_time=ic_t,
            end_time=ic_end_t,
            start_idx=ic_event.frame_start,
            end_idx=ic_end_idx,
            duration=ic_end_t - ic_t,
            phase_number=1
        ))

        # Phase 2: Loading Response (IC → mid-stance start)
        if ms_event:
            lr_start_t = ic_end_t
            lr_end_t = ms_event.event_start
            lr_start_idx = ic_end_idx
            lr_end_idx = ms_event.frame_start
        else:
            # Estimate LR as first 20% of stance if no mid-stance detected
            lr_start_t = ic_end_t
            lr_end_t = ic_t + (to_t - ic_t) * 0.2
            lr_start_idx = ic_end_idx
            lr_end_idx = np.argmin(np.abs(df['timestamp'].values - lr_end_t))

        phases.append(GaitPhase(
            phase_name='Loading Response',
            leg=leg,
            start_time=lr_start_t,
            end_time=lr_end_t,
            start_idx=lr_start_idx,
            end_idx=lr_end_idx,
            duration=lr_end_t - lr_start_t,
            phase_number=2
        ))

        # Phase 3: Mid-Stance (mid-stance event duration)
        if ms_event:
            mst_start_t = ms_event.event_start
            mst_end_t = ms_event.event_end
            mst_start_idx = ms_event.frame_start
            mst_end_idx = ms_event.frame_end
        else:
            # Estimate MSt as 20-60% of stance
            mst_start_t = lr_end_t
            mst_end_t = ic_t + (to_t - ic_t) * 0.6
            mst_start_idx = lr_end_idx
            mst_end_idx = np.argmin(np.abs(df['timestamp'].values - mst_end_t))

        phases.append(GaitPhase(
            phase_name='Mid-Stance',
            leg=leg,
            start_time=mst_start_t,
            end_time=mst_end_t,
            start_idx=mst_start_idx,
            end_idx=mst_end_idx,
            duration=mst_end_t - mst_start_t,
            phase_number=3
        ))

        # Phase 4: Terminal Stance (mid-stance end → 90% of stance)
        stance_duration = to_t - ic_t
        tst_start_t = mst_end_t
        tst_end_t = ic_t + stance_duration * 0.9
        tst_start_idx = mst_end_idx
        tst_end_idx = np.argmin(np.abs(df['timestamp'].values - tst_end_t))

        phases.append(GaitPhase(
            phase_name='Terminal Stance',
            leg=leg,
            start_time=tst_start_t,
            end_time=tst_end_t,
            start_idx=tst_start_idx,
            end_idx=tst_end_idx,
            duration=tst_end_t - tst_start_t,
            phase_number=4
        ))

        # Phase 5: Pre-Swing (last 10% before toe-off)
        psw_start_t = tst_end_t
        psw_end_t = to_t
        psw_start_idx = tst_end_idx
        psw_end_idx = to_event.frame_end

        phases.append(GaitPhase(
            phase_name='Pre-Swing',
            leg=leg,
            start_time=psw_start_t,
            end_time=psw_end_t,
            start_idx=psw_start_idx,
            end_idx=psw_end_idx,
            duration=psw_end_t - psw_start_t,
            phase_number=5
        ))

        # 5. Build swing phases (divide into thirds with validation)
        swing_duration = next_ic_t - to_t

        # Validate swing duration (0.3-0.6s typical at normal walking speed)
        if swing_duration < 0.25 or swing_duration > 0.8:
            # Invalid swing - might indicate detection error
            print(f"  Warning: Unusual swing duration {swing_duration:.3f}s for {leg} leg")

        swing_phase_duration = swing_duration / 3.0

        swing_phases = [
            ('Initial Swing', 6),
            ('Mid-Swing', 7),
            ('Terminal Swing', 8)
        ]

        for i, (name, num) in enumerate(swing_phases):
            phase_start_t = to_t + i * swing_phase_duration
            phase_end_t = to_t + (i + 1) * swing_phase_duration

            phase_start_idx = np.argmin(np.abs(df['timestamp'].values - phase_start_t))
            phase_end_idx = np.argmin(np.abs(df['timestamp'].values - phase_end_t))

            phases.append(GaitPhase(
                phase_name=name,
                leg=leg,
                start_time=phase_start_t,
                end_time=phase_end_t,
                start_idx=phase_start_idx,
                end_idx=phase_end_idx,
                duration=phase_end_t - phase_start_t,
                phase_number=num
            ))

        return phases

    def _detect_phases_heuristic(self, df: pd.DataFrame, leg: str,
                                 start_idx: int, end_idx: int,
                                 timestamps: np.ndarray) -> List[GaitPhase]:
        """
        Fallback heuristic phase detection when precision events unavailable.

        Uses time-based segmentation with pressure signal analysis.
        """
        pressure = df.iloc[start_idx:end_idx][f'{leg}_pressure_total'].values
        phases = []

        # Detect toe-off using pressure threshold
        to_idx = self._detect_toe_off(pressure)
        if to_idx is None or to_idx >= len(timestamps) - 10:
            to_idx = int(0.6 * len(timestamps))  # 60% heuristic

        # Initial Contact (first 5% of cycle)
        ic_end_idx = max(5, int(0.05 * len(timestamps)))
        phases.append(GaitPhase(
            phase_name='Initial Contact',
            leg=leg,
            start_time=timestamps[0],
            end_time=timestamps[ic_end_idx],
            start_idx=start_idx,
            end_idx=start_idx + ic_end_idx,
            duration=timestamps[ic_end_idx] - timestamps[0],
            phase_number=1
        ))

        # Stance phases (divide into 4 equal segments)
        stance_phases = [
            ('Loading Response', 2),
            ('Mid-Stance', 3),
            ('Terminal Stance', 4),
            ('Pre-Swing', 5)
        ]

        for i, (name, num) in enumerate(stance_phases):
            phase_start_idx = ic_end_idx + int(i * (to_idx - ic_end_idx) / 4)
            phase_end_idx = ic_end_idx + min(int((i + 1) * (to_idx - ic_end_idx) / 4), to_idx)

            phases.append(GaitPhase(
                phase_name=name,
                leg=leg,
                start_time=timestamps[phase_start_idx],
                end_time=timestamps[phase_end_idx],
                start_idx=start_idx + phase_start_idx,
                end_idx=start_idx + phase_end_idx,
                duration=timestamps[phase_end_idx] - timestamps[phase_start_idx],
                phase_number=num
            ))

        # Swing phases (divide into 3 equal segments)
        swing_phases = [
            ('Initial Swing', 6),
            ('Mid-Swing', 7),
            ('Terminal Swing', 8)
        ]

        swing_len = len(timestamps) - to_idx
        for i, (name, num) in enumerate(swing_phases):
            phase_start_idx = to_idx + int(i * swing_len / 3)
            phase_end_idx = to_idx + min(int((i + 1) * swing_len / 3), len(timestamps) - 1)

            phases.append(GaitPhase(
                phase_name=name,
                leg=leg,
                start_time=timestamps[phase_start_idx],
                end_time=timestamps[phase_end_idx],
                start_idx=start_idx + phase_start_idx,
                end_idx=start_idx + phase_end_idx,
                duration=timestamps[phase_end_idx] - timestamps[phase_start_idx],
                phase_number=num
            ))

        return phases

    def _detect_toe_off(self, pressure: np.ndarray) -> Optional[int]:
        """
        Detect toe-off event (end of stance, start of swing).

        Biomechanical signature: Pressure drops to near zero
        """
        # Find first sustained low pressure after initial contact
        threshold = self.config.pressure_threshold * 0.3

        for i in range(10, len(pressure) - 10):
            # Check if pressure drops and stays low
            if np.all(pressure[i:i+5] < threshold):
                return i

        return None


# ============================================================================
# CYCLOGRAM GENERATOR
# ============================================================================

class CyclogramGenerator:
    """Generate IMU-based coordination cyclograms for gait cycles."""

    def __init__(self, config: InsoleConfig):
        self.config = config

    def generate_cyclograms(self, df: pd.DataFrame,
                           cycles: List[GaitCycle],
                           leg: str) -> List[CyclogramData]:
        """
        Generate multiple cyclogram types for each gait cycle.

        Cyclogram types:
        1. ACC_X vs ACC_Y (sagittal-frontal acceleration)
        2. ACC_Z vs GYRO_Y (vertical acc vs pitch rate)
        3. GYRO_X vs GYRO_Z (roll-yaw coordination)
        """
        cyclograms = []

        # Convert leg name to uppercase prefix
        leg_prefix = 'L' if leg == 'left' else 'R'

        cyclogram_types = [
            (f'{leg_prefix}_ACC_X_filt', f'{leg_prefix}_ACC_Y_filt', 'ACC_X', 'ACC_Y'),
            (f'{leg_prefix}_ACC_Z_filt', f'{leg_prefix}_GYRO_Y_filt', 'ACC_Z', 'GYRO_Y'),
            (f'{leg_prefix}_GYRO_X_filt', f'{leg_prefix}_GYRO_Z_filt', 'GYRO_X', 'GYRO_Z')
        ]

        for cycle in cycles:
            for x_col, y_col, x_label, y_label in cyclogram_types:
                cyclogram = self._extract_cyclogram(
                    df, cycle, x_col, y_col, x_label, y_label
                )
                cyclograms.append(cyclogram)

        return cyclograms

    def _extract_cyclogram(self, df: pd.DataFrame, cycle: GaitCycle,
                          x_col: str, y_col: str,
                          x_label: str, y_label: str) -> CyclogramData:
        """Extract single cyclogram for one cycle."""

        # Get cycle data
        start_idx = cycle.phases[0].start_idx
        end_idx = cycle.phases[-1].end_idx

        cycle_data = df.iloc[start_idx:end_idx]

        x_signal = cycle_data[x_col].values
        y_signal = cycle_data[y_col].values

        # Normalize to percentage of gait cycle
        normalized_length = self.config.cyclogram_resolution

        if len(x_signal) < 2:
            # Handle edge case
            x_signal_norm = np.zeros(normalized_length)
            y_signal_norm = np.zeros(normalized_length)
        else:
            time_original = np.linspace(0, 100, len(x_signal))
            time_normalized = np.linspace(0, 100, normalized_length)

            x_interp = interp1d(time_original, x_signal, kind='cubic',
                               fill_value='extrapolate')
            y_interp = interp1d(time_original, y_signal, kind='cubic',
                               fill_value='extrapolate')

            x_signal_norm = x_interp(time_normalized)
            y_signal_norm = y_interp(time_normalized)

        # Compute phase boundary indices in normalized space
        phase_indices = []
        phase_labels = []

        for phase in cycle.phases:
            # Convert absolute index to relative position in cycle
            relative_start = phase.start_idx - start_idx
            relative_pos = (relative_start / len(cycle_data)) * normalized_length
            phase_indices.append(int(relative_pos))
            phase_labels.append(phase.phase_name)

        return CyclogramData(
            cycle=cycle,
            x_signal=x_signal_norm,
            y_signal=y_signal_norm,
            x_label=x_label,
            y_label=y_label,
            phase_indices=phase_indices,
            phase_labels=phase_labels
        )


# ============================================================================
# VALIDATION ENGINE
# ============================================================================

class ValidationEngine:
    """Anatomical plausibility validation for detected gait patterns."""

    def __init__(self, config: InsoleConfig):
        self.config = config

    def validate_gait_cycles(self, left_cycles: List[GaitCycle],
                            right_cycles: List[GaitCycle]) -> ValidationMetrics:
        """
        Comprehensive validation of detected gait cycles.

        Checks:
        1. Left-right alternation
        2. Stance-to-swing ratio
        3. Bilateral symmetry
        4. Phase sequence integrity
        5. Duration constraints
        """
        issues = []

        # Check 1: Left-right alternation
        alternation_valid = self._check_alternation(left_cycles, right_cycles)
        if not alternation_valid:
            issues.append("Left-right IC events do not alternate properly")

        # Check 2: Stance-swing ratio
        ratio_valid = self._check_stance_swing_ratio(left_cycles + right_cycles)
        if not ratio_valid:
            issues.append("Stance-to-swing ratio outside expected range")

        # Check 3: Bilateral symmetry
        symmetry_valid = self._check_bilateral_symmetry(left_cycles, right_cycles)
        if not symmetry_valid:
            issues.append("Left-right cycle durations differ significantly")

        # Check 4: Phase sequence
        sequence_valid = self._check_phase_sequence(left_cycles + right_cycles)
        if not sequence_valid:
            issues.append("Phase sequence violated in some cycles")

        # Check 5: Duration constraints
        duration_valid = self._check_duration_constraints(left_cycles + right_cycles)
        if not duration_valid:
            issues.append("Phase durations outside biomechanical constraints")

        overall_valid = (alternation_valid and ratio_valid and
                        symmetry_valid and sequence_valid and duration_valid)

        return ValidationMetrics(
            left_right_alternation=alternation_valid,
            stance_swing_ratio_valid=ratio_valid,
            bilateral_symmetry_valid=symmetry_valid,
            phase_sequence_valid=sequence_valid,
            duration_constraints_valid=duration_valid,
            overall_valid=overall_valid,
            issues=issues
        )

    def _check_alternation(self, left_cycles: List[GaitCycle],
                          right_cycles: List[GaitCycle]) -> bool:
        """Verify left and right ICs alternate (not simultaneous)."""

        if not left_cycles or not right_cycles:
            return False

        # Collect all IC times with leg labels
        all_ics = []
        for cycle in left_cycles:
            all_ics.append((cycle.start_time, 'left'))
        for cycle in right_cycles:
            all_ics.append((cycle.start_time, 'right'))

        # Sort by time
        all_ics.sort(key=lambda x: x[0])

        # Check for alternation
        for i in range(len(all_ics) - 1):
            if all_ics[i][1] == all_ics[i+1][1]:
                # Same leg twice in a row
                time_diff = all_ics[i+1][0] - all_ics[i][0]
                if time_diff < 0.3:  # Too close, likely detection error
                    return False

        return True

    def _check_stance_swing_ratio(self, cycles: List[GaitCycle]) -> bool:
        """Verify stance-to-swing ratio is within expected range (1.2-2.0)."""

        for cycle in cycles:
            ratio = cycle.stance_swing_ratio
            if not (self.config.stance_swing_ratio_min <= ratio <=
                   self.config.stance_swing_ratio_max):
                return False

        return True

    def _check_bilateral_symmetry(self, left_cycles: List[GaitCycle],
                                  right_cycles: List[GaitCycle]) -> bool:
        """Verify left and right cycles have similar durations."""

        if not left_cycles or not right_cycles:
            return True

        left_mean = np.mean([c.duration for c in left_cycles])
        right_mean = np.mean([c.duration for c in right_cycles])

        diff_ratio = abs(left_mean - right_mean) / ((left_mean + right_mean) / 2)

        return diff_ratio <= self.config.bilateral_tolerance

    def _check_phase_sequence(self, cycles: List[GaitCycle]) -> bool:
        """Verify phases occur in correct anatomical order."""

        expected_sequence = list(range(1, 9))  # 1-8

        for cycle in cycles:
            actual_sequence = [p.phase_number for p in cycle.phases]
            if actual_sequence != expected_sequence:
                return False

        return True

    def _check_duration_constraints(self, cycles: List[GaitCycle]) -> bool:
        """Verify phase durations are biomechanically plausible."""

        for cycle in cycles:
            # Check stance duration
            if not (self.config.min_stance_duration <= cycle.stance_duration):
                return False

            # Check swing duration
            if not (self.config.min_swing_duration <= cycle.swing_duration):
                return False

        return True


# ============================================================================
# SYMMETRY ANALYZER
# ============================================================================

class SymmetryAnalyzer:
    """
    Bilateral symmetry and morphology metrics for gait analysis.

    Quantifies left-vs-right similarity across cyclogram types using:
    - Geometric metrics: Area, curvature distribution
    - Temporal metrics: Smoothness coefficient (inverse jerk)
    - Morphological comparison: Shape similarity indices
    """

    def __init__(self, config: InsoleConfig):
        self.config = config

    def compute_area(self, x: np.ndarray, y: np.ndarray) -> float:
        """
        Compute polygonal area enclosed by cyclogram using shoelace formula.

        Args:
            x: X-coordinates of cyclogram trajectory
            y: Y-coordinates of cyclogram trajectory

        Returns:
            Absolute area enclosed by the loop
        """
        return 0.5 * np.abs(np.dot(x, np.roll(y, 1)) - np.dot(y, np.roll(x, 1)))

    def compute_curvature(self, x: np.ndarray, y: np.ndarray) -> np.ndarray:
        """
        Compute curvature along 2D trajectory.

        Curvature κ = |x'y'' - y'x''| / (x'² + y'²)^(3/2)

        Args:
            x: X-coordinates of trajectory
            y: Y-coordinates of trajectory

        Returns:
            Curvature array along trajectory
        """
        dx = np.gradient(x)
        dy = np.gradient(y)
        ddx = np.gradient(dx)
        ddy = np.gradient(dy)

        numerator = np.abs(dx * ddy - dy * ddx)
        denominator = np.power(dx**2 + dy**2 + 1e-6, 1.5)

        curvature = numerator / denominator
        return curvature

    def compute_smoothness(self, x: np.ndarray, y: np.ndarray) -> float:
        """
        Compute smoothness coefficient as inverse of mean jerk.

        Smoothness = 1 / mean(|jerk|)
        Higher values indicate smoother, more controlled movement.

        Args:
            x: X-coordinates of trajectory
            y: Y-coordinates of trajectory

        Returns:
            Smoothness coefficient (higher = smoother)
        """
        # Compute jerk (third derivative of position)
        dx = np.gradient(x)
        dy = np.gradient(y)
        ddx = np.gradient(dx)
        ddy = np.gradient(dy)

        # Jerk magnitude
        jerk = ddx**2 + ddy**2

        # Smoothness as inverse of mean jerk
        smoothness = 1.0 / (np.mean(jerk) + 1e-6)

        return smoothness

    def compare_cyclograms(self, left: CyclogramData, right: CyclogramData) -> Dict[str, float]:
        """
        Compare left vs right cyclogram geometry and morphology.

        Computes bilateral symmetry metrics:
        - Area symmetry: normalized difference in enclosed areas
        - Curvature symmetry: RMS difference in curvature profiles
        - Smoothness symmetry: difference in movement smoothness

        Args:
            left: Left leg cyclogram data
            right: Right leg cyclogram data

        Returns:
            Dictionary with symmetry metrics and individual leg measurements
        """
        # Compute geometric properties for each leg
        A_L = self.compute_area(left.x_signal, left.y_signal)
        A_R = self.compute_area(right.x_signal, right.y_signal)

        κ_L = self.compute_curvature(left.x_signal, left.y_signal)
        κ_R = self.compute_curvature(right.x_signal, right.y_signal)

        S_L = self.compute_smoothness(left.x_signal, left.y_signal)
        S_R = self.compute_smoothness(right.x_signal, right.y_signal)

        # Compute symmetry indices (normalized differences)
        # Symmetry = 1 - normalized_difference (1.0 = perfect symmetry)

        area_diff = np.abs(A_L - A_R) / ((A_L + A_R) / 2 + 1e-6)
        area_symmetry = 1.0 - area_diff

        curvature_diff = np.mean(np.abs(κ_L - κ_R)) / (np.mean([κ_L.mean(), κ_R.mean()]) + 1e-6)
        curvature_symmetry = 1.0 - curvature_diff

        smoothness_diff = np.abs(S_L - S_R) / ((S_L + S_R) / 2 + 1e-6)
        smoothness_symmetry = 1.0 - smoothness_diff

        # Compute overall symmetry score (mean of z-scored metrics)
        symmetry_scores = np.array([area_symmetry, curvature_symmetry, smoothness_symmetry])
        overall_symmetry = np.mean(symmetry_scores)

        return {
            'area_symmetry': area_symmetry,
            'curvature_symmetry': curvature_symmetry,
            'smoothness_symmetry': smoothness_symmetry,
            'overall_symmetry': overall_symmetry,
            'area_L': A_L,
            'area_R': A_R,
            'curvature_mean_L': κ_L.mean(),
            'curvature_mean_R': κ_R.mean(),
            'curvature_var_L': κ_L.var(),
            'curvature_var_R': κ_R.var(),
            'smoothness_L': S_L,
            'smoothness_R': S_R
        }

    def compute_batch_symmetry(self, left_cyclograms: List[CyclogramData],
                               right_cyclograms: List[CyclogramData]) -> pd.DataFrame:
        """
        Compute symmetry metrics for all cyclogram pairs.

        Args:
            left_cyclograms: List of left leg cyclograms
            right_cyclograms: List of right leg cyclograms

        Returns:
            DataFrame with per-cycle and aggregate symmetry metrics
        """
        results = []

        # Group cyclograms by type (ACC_X_vs_ACC_Y, etc.)
        left_by_type = {}
        right_by_type = {}

        for cyclogram in left_cyclograms:
            key = (cyclogram.x_label, cyclogram.y_label)
            if key not in left_by_type:
                left_by_type[key] = []
            left_by_type[key].append(cyclogram)

        for cyclogram in right_cyclograms:
            key = (cyclogram.x_label, cyclogram.y_label)
            if key not in right_by_type:
                right_by_type[key] = []
            right_by_type[key].append(cyclogram)

        # Compare paired cyclograms
        for key in left_by_type.keys():
            if key not in right_by_type:
                continue

            left_cycles = left_by_type[key]
            right_cycles = right_by_type[key]

            # Compare cycle-by-cycle
            for i, (L, R) in enumerate(zip(left_cycles, right_cycles)):
                metrics = self.compare_cyclograms(L, R)
                metrics['cycle_id'] = i + 1
                metrics['cyclogram_type'] = f"{L.x_label}_vs_{L.y_label}"
                results.append(metrics)

        return pd.DataFrame(results)


# ============================================================================
# VISUALIZER
# ============================================================================

class InsoleVisualizer:
    """Visualization generation for insole gait analysis."""

    def __init__(self, config: InsoleConfig):
        self.config = config
        self._setup_colors()

    def _setup_colors(self):
        """Define color scheme for phase segmentation."""
        # Stance phases: Blue gradient
        self.stance_colors = [
            '#08519c',  # IC - dark blue
            '#3182bd',  # LR
            '#6baed6',  # MSt
            '#9ecae1',  # TSt
            '#c6dbef'   # PSw - light blue
        ]

        # Swing phases: Red gradient
        self.swing_colors = [
            '#a50f15',  # ISw - dark red
            '#de2d26',  # MSw
            '#fc9272'   # TSw - light red
        ]

        self.phase_colors = self.stance_colors + self.swing_colors

    def plot_phase_segmented_cyclogram(self, cyclogram: CyclogramData,
                                      output_path: Path):
        """
        Plot cyclogram with phase-based color segmentation.
        """
        fig, ax = plt.subplots(figsize=(10, 10), dpi=self.config.plot_dpi)

        x = cyclogram.x_signal
        y = cyclogram.y_signal

        # Plot full trajectory in light gray
        ax.plot(x, y, color='lightgray', linewidth=0.5, alpha=0.5)

        # Plot phase segments with colors
        phase_indices = cyclogram.phase_indices + [len(x)]  # Add endpoint

        for i in range(len(cyclogram.phase_indices)):
            start_idx = phase_indices[i]
            end_idx = phase_indices[i + 1]

            color = self.phase_colors[i % len(self.phase_colors)]

            ax.plot(x[start_idx:end_idx], y[start_idx:end_idx],
                   color=color, linewidth=2,
                   label=cyclogram.phase_labels[i])

        # Mark start/end
        ax.plot(x[0], y[0], 'go', markersize=10, label='IC (Start)')
        ax.plot(x[-1], y[-1], 'rs', markersize=10, label='IC (End)')

        # Formatting
        ax.set_xlabel(f'{cyclogram.x_label} (filtered)', fontsize=12, fontweight='bold')
        ax.set_ylabel(f'{cyclogram.y_label} (filtered)', fontsize=12, fontweight='bold')
        ax.set_title(f'{cyclogram.cycle.leg.title()} Leg Cyclogram - '
                    f'Cycle {cyclogram.cycle.cycle_id}\n'
                    f'Duration: {cyclogram.cycle.duration:.2f}s, '
                    f'Stance/Swing: {cyclogram.cycle.stance_swing_ratio:.2f}',
                    fontsize=14, fontweight='bold')

        ax.legend(loc='best', fontsize=8, ncol=2)
        ax.grid(True, alpha=0.3)
        ax.set_aspect('equal', adjustable='box')

        plt.tight_layout()
        plt.savefig(output_path)
        plt.close()

        print(f"  Saved cyclogram: {output_path}")

    def plot_aggregated_cyclogram(self, cyclograms: List[CyclogramData],
                                 output_path: Path):
        """
        Plot mean cyclogram with all individual cycles overlaid.
        """
        if not cyclograms:
            return

        fig, ax = plt.subplots(figsize=(10, 10), dpi=self.config.plot_dpi)

        # Plot individual cycles in light gray
        for cyclogram in cyclograms:
            ax.plot(cyclogram.x_signal, cyclogram.y_signal,
                   color='lightgray', linewidth=0.5, alpha=0.3)

        # Compute mean cyclogram
        x_mean = np.mean([c.x_signal for c in cyclograms], axis=0)
        y_mean = np.mean([c.y_signal for c in cyclograms], axis=0)

        # Plot mean with phase segmentation
        phase_indices = cyclograms[0].phase_indices + [len(x_mean)]

        for i in range(len(cyclograms[0].phase_indices)):
            start_idx = phase_indices[i]
            end_idx = phase_indices[i + 1]

            color = self.phase_colors[i % len(self.phase_colors)]

            ax.plot(x_mean[start_idx:end_idx], y_mean[start_idx:end_idx],
                   color=color, linewidth=3,
                   label=cyclograms[0].phase_labels[i])

        # Mark start/end
        ax.plot(x_mean[0], y_mean[0], 'go', markersize=12, label='IC (Start)')
        ax.plot(x_mean[-1], y_mean[-1], 'rs', markersize=12, label='IC (End)')

        # Formatting
        leg = cyclograms[0].cycle.leg
        x_label = cyclograms[0].x_label
        y_label = cyclograms[0].y_label

        ax.set_xlabel(f'{x_label} (filtered)', fontsize=12, fontweight='bold')
        ax.set_ylabel(f'{y_label} (filtered)', fontsize=12, fontweight='bold')
        ax.set_title(f'{leg.title()} Leg Mean Cyclogram ({len(cyclograms)} cycles)\n'
                    f'{x_label} vs {y_label}',
                    fontsize=14, fontweight='bold')

        ax.legend(loc='best', fontsize=8, ncol=2)
        ax.grid(True, alpha=0.3)
        ax.set_aspect('equal', adjustable='box')

        plt.tight_layout()
        plt.savefig(output_path)
        plt.close()

        print(f"  Saved aggregated cyclogram: {output_path}")


# ============================================================================
# MAIN ANALYSIS PIPELINE
# ============================================================================

class InsolePipeline:
    """Main orchestrator for insole gait analysis."""

    def __init__(self, config: InsoleConfig, use_precision_detection: bool = True):
        self.config = config
        self.loader = InsoleLoader(config)
        self.processor = SignalProcessor(config)

        # Initialize precision detector if requested
        self.precision_detector = PressureSensorZoneDetector(config) if use_precision_detection else None

        # Pass precision detector to phase detector
        self.phase_detector = GaitPhaseDetector(config, precision_detector=self.precision_detector)

        self.cyclogram_generator = CyclogramGenerator(config)
        self.validator = ValidationEngine(config)
        self.symmetry_analyzer = SymmetryAnalyzer(config)
        self.visualizer = InsoleVisualizer(config)

    def analyze_insole_data(self, input_csv: Path, output_dir: Path):
        """
        Complete analysis pipeline for smart insole data.

        Stages:
        1. Load and preprocess data
        2. Self-calibration (baseline correction + adaptive filter tuning)
        3. Feature extraction (with adaptive filtering)
        4. Gait phase detection
        5. Cyclogram generation
        6. Bilateral symmetry analysis
        7. Validation and visualization
        """
        print("="*70)
        print("SMART INSOLE GAIT ANALYSIS")
        print("="*70)

        # Stage 1: Load data
        df = self.loader.load_data(input_csv)
        col_map = self.loader.detect_column_mapping(df)

        # Stage 2: Self-calibration
        print("\nPerforming self-calibration...")
        df = self.processor.calibrate_signals(df, col_map)

        # Stage 3: Feature extraction
        print("\nExtracting features...")
        df = self.processor.compute_pressure_features(df, col_map)
        df = self.processor.compute_imu_features(df, col_map)
        print("  Feature extraction complete")

        # Stage 3: Gait phase detection
        left_cycles = self.phase_detector.detect_gait_cycles(df, 'left')
        right_cycles = self.phase_detector.detect_gait_cycles(df, 'right')

        # Stage 4: Cyclogram generation
        print("\nGenerating cyclograms...")
        left_cyclograms = self.cyclogram_generator.generate_cyclograms(
            df, left_cycles, 'left'
        )
        right_cyclograms = self.cyclogram_generator.generate_cyclograms(
            df, right_cycles, 'right'
        )
        print(f"  Generated {len(left_cyclograms)} left cyclograms")
        print(f"  Generated {len(right_cyclograms)} right cyclograms")

        # Stage 5: Validation
        print("\nValidating anatomical plausibility...")
        validation = self.validator.validate_gait_cycles(left_cycles, right_cycles)

        self._print_validation_results(validation)

        # Stage 6: Bilateral Symmetry Analysis
        print("\nComputing bilateral symmetry metrics...")
        symmetry_metrics = self._compute_symmetry(left_cyclograms, right_cyclograms)

        # Stage 7: Visualization
        output_dir.mkdir(parents=True, exist_ok=True)

        # Use enhanced visualizer if available
        if ENHANCED_VIZ_AVAILABLE:
            print("\nGenerating enhanced visualization suite...")
            plot_config = PlotConfig(dpi=self.config.plot_dpi)
            enhanced_viz = EnhancedInsoleVisualizer(plot_config)
            enhanced_viz.generate_all_plot_sets(left_cycles, right_cycles, df, output_dir)
        else:
            print("\nGenerating standard visualizations...")

            # Plot individual cyclograms (first 3 of each type)
            cyclogram_types = {}
            for cyclogram in left_cyclograms + right_cyclograms:
                key = (cyclogram.cycle.leg, cyclogram.x_label, cyclogram.y_label)
                if key not in cyclogram_types:
                    cyclogram_types[key] = []
                cyclogram_types[key].append(cyclogram)

            for (leg, x_label, y_label), cyclograms in cyclogram_types.items():
                # Plot first 3 individual cycles
                for i, cyclogram in enumerate(cyclograms[:3]):
                    output_path = output_dir / f"{leg}_{x_label}_vs_{y_label}_cycle_{i+1}.png"
                    self.visualizer.plot_phase_segmented_cyclogram(cyclogram, output_path)

                # Plot aggregated mean
                output_path = output_dir / f"{leg}_{x_label}_vs_{y_label}_mean.png"
                self.visualizer.plot_aggregated_cyclogram(cyclograms, output_path)

        # Save summary
        self._save_summary(left_cycles, right_cycles, validation, output_dir)

        # Save symmetry metrics
        self._save_symmetry_results(symmetry_metrics, output_dir)

        # Save precision events if available
        if self.precision_detector is not None:
            self._save_precision_events(df, output_dir)
            # Create debug validation plots
            self.create_debug_event_validation_plot(df, output_dir)

        print("\n" + "="*70)
        print("ANALYSIS COMPLETE")
        print("="*70)

    def _print_validation_results(self, validation: ValidationMetrics):
        """Print validation results to console."""

        print("\n  Validation Results:")
        print(f"    Left-Right Alternation: {'✓' if validation.left_right_alternation else '✗'}")
        print(f"    Stance-Swing Ratio: {'✓' if validation.stance_swing_ratio_valid else '✗'}")
        print(f"    Bilateral Symmetry: {'✓' if validation.bilateral_symmetry_valid else '✗'}")
        print(f"    Phase Sequence: {'✓' if validation.phase_sequence_valid else '✗'}")
        print(f"    Duration Constraints: {'✓' if validation.duration_constraints_valid else '✗'}")
        print(f"\n    Overall Valid: {'✓ PASS' if validation.overall_valid else '✗ FAIL'}")

        if validation.issues:
            print("\n  Issues Found:")
            for issue in validation.issues:
                print(f"    - {issue}")

    def _save_summary(self, left_cycles: List[GaitCycle],
                     right_cycles: List[GaitCycle],
                     validation: ValidationMetrics,
                     output_dir: Path):
        """Save analysis summary to CSV."""

        summary_data = []

        for cycle in left_cycles + right_cycles:
            summary_data.append({
                'leg': cycle.leg,
                'cycle_id': cycle.cycle_id,
                'duration': cycle.duration,
                'stance_duration': cycle.stance_duration,
                'swing_duration': cycle.swing_duration,
                'stance_swing_ratio': cycle.stance_swing_ratio,
                'start_time': cycle.start_time,
                'end_time': cycle.end_time
            })

        df_summary = pd.DataFrame(summary_data)
        summary_path = output_dir / 'gait_cycle_summary.csv'
        df_summary.to_csv(summary_path, index=False)

        print(f"\n  Saved summary: {summary_path}")

    def _compute_symmetry(self, left_cyclograms: List[CyclogramData],
                         right_cyclograms: List[CyclogramData]) -> pd.DataFrame:
        """
        Compute bilateral symmetry metrics for all cyclogram pairs.

        Args:
            left_cyclograms: List of left leg cyclograms
            right_cyclograms: List of right leg cyclograms

        Returns:
            DataFrame with per-cycle symmetry metrics
        """
        symmetry_df = self.symmetry_analyzer.compute_batch_symmetry(
            left_cyclograms, right_cyclograms
        )

        # Print summary statistics
        if not symmetry_df.empty:
            print(f"  Computed symmetry for {len(symmetry_df)} cyclogram pairs")

            # Aggregate by cyclogram type
            type_summary = symmetry_df.groupby('cyclogram_type').agg({
                'area_symmetry': ['mean', 'std'],
                'curvature_symmetry': ['mean', 'std'],
                'smoothness_symmetry': ['mean', 'std'],
                'overall_symmetry': ['mean', 'std']
            })

            print("\n  Symmetry Summary (mean ± std):")
            for cyclogram_type in type_summary.index:
                area_sym = type_summary.loc[cyclogram_type, ('area_symmetry', 'mean')]
                curv_sym = type_summary.loc[cyclogram_type, ('curvature_symmetry', 'mean')]
                smooth_sym = type_summary.loc[cyclogram_type, ('smoothness_symmetry', 'mean')]
                overall = type_summary.loc[cyclogram_type, ('overall_symmetry', 'mean')]

                print(f"    {cyclogram_type}:")
                print(f"      Area: {area_sym:.3f}, Curvature: {curv_sym:.3f}, "
                      f"Smoothness: {smooth_sym:.3f}, Overall: {overall:.3f}")

        return symmetry_df

    def _save_symmetry_results(self, symmetry_df: pd.DataFrame, output_dir: Path):
        """
        Save bilateral symmetry metrics to CSV.

        Args:
            symmetry_df: DataFrame with symmetry metrics
            output_dir: Directory to save results
        """
        if symmetry_df.empty:
            print("  No symmetry metrics to save")
            return

        symmetry_path = output_dir / 'symmetry_metrics.csv'
        symmetry_df.to_csv(symmetry_path, index=False)

        print(f"\n  Saved symmetry metrics: {symmetry_path}")

        # Compute and save aggregate summary
        aggregate = symmetry_df.groupby('cyclogram_type').agg({
            'area_L': 'mean',
            'area_R': 'mean',
            'area_symmetry': ['mean', 'std'],
            'curvature_mean_L': 'mean',
            'curvature_mean_R': 'mean',
            'curvature_symmetry': ['mean', 'std'],
            'smoothness_L': 'mean',
            'smoothness_R': 'mean',
            'smoothness_symmetry': ['mean', 'std'],
            'overall_symmetry': ['mean', 'std']
        })

        aggregate_path = output_dir / 'symmetry_aggregate.csv'
        aggregate.to_csv(aggregate_path)

        print(f"  Saved aggregate summary: {aggregate_path}")

    def _save_precision_events(self, df: pd.DataFrame, output_dir: Path):
        """Save high-precision gait events to CSV for validation."""

        print("\n  Exporting precision gait events...")

        all_events = []

        for leg in ['left', 'right']:
            events = self.precision_detector.detect_all_events(df, leg)

            for event_type, event_list in events.items():
                for event in event_list:
                    all_events.append({
                        'leg': event.leg,
                        'event_type': event.event_type,
                        'event_start_time': event.event_start,
                        'event_end_time': event.event_end,
                        'duration_ms': event.duration,
                        'sensor_source': event.sensor_source,
                        'frame_start': event.frame_start,
                        'frame_end': event.frame_end,
                        'confidence': event.confidence
                    })

        df_events = pd.DataFrame(all_events)
        df_events = df_events.sort_values(['leg', 'event_start_time'])

        events_path = output_dir / 'precision_gait_events.csv'
        df_events.to_csv(events_path, index=False)

        print(f"  Saved {len(all_events)} precision events: {events_path}")

        # Print summary statistics
        for leg in ['left', 'right']:
            leg_events = df_events[df_events['leg'] == leg]
            for event_type in ['heel_strike', 'mid_stance', 'toe_off']:
                type_events = leg_events[leg_events['event_type'] == event_type]
                if len(type_events) > 0:
                    avg_duration = type_events['duration_ms'].mean()
                    avg_confidence = type_events['confidence'].mean()
                    print(f"    {leg.title()} {event_type}: {len(type_events)} events, "
                          f"avg duration={avg_duration:.1f}ms, avg confidence={avg_confidence:.3f}")

    def create_debug_event_validation_plot(self, df: pd.DataFrame, output_dir: Path):
        """
        Create debug visualization to validate precision event detection timing.

        Shows pressure signal with overlaid event markers for visual QA.
        """
        print("\n  Creating debug event validation plots...")

        debug_dir = output_dir / "debug"
        debug_dir.mkdir(parents=True, exist_ok=True)

        for leg in ['left', 'right']:
            leg_prefix = 'L' if leg == 'left' else 'R'
            pressure_col = f'{leg}_pressure_total'

            if pressure_col not in df.columns:
                continue

            # Get all events for this leg
            events = self.precision_detector.detect_all_events(df, leg)

            # Create figure
            fig, ax = plt.subplots(figsize=(16, 6), dpi=150)

            # Plot pressure signal
            timestamps = df['timestamp'].values
            pressure = df[pressure_col].values

            ax.plot(timestamps, pressure, color='black', linewidth=1, alpha=0.7,
                   label='Total Pressure')

            # Overlay heel strike events (green)
            for event in events['heel_strike']:
                ax.axvline(event.event_start, color='green', linestyle='--',
                          linewidth=1.5, alpha=0.7, label='HS' if event == events['heel_strike'][0] else '')
                ax.axvspan(event.event_start, event.event_end, color='green',
                          alpha=0.1)

            # Overlay mid-stance events (blue)
            for event in events['mid_stance']:
                ax.axvspan(event.event_start, event.event_end, color='blue',
                          alpha=0.2, label='MSt' if event == events['mid_stance'][0] else '')

            # Overlay toe-off events (red)
            for event in events['toe_off']:
                ax.axvline(event.event_end, color='red', linestyle='--',
                          linewidth=1.5, alpha=0.7, label='TO' if event == events['toe_off'][0] else '')
                ax.axvspan(event.event_start, event.event_end, color='red',
                          alpha=0.1)

            # Formatting
            ax.set_xlabel('Time (seconds)', fontsize=12, fontweight='bold')
            ax.set_ylabel('Pressure (normalized)', fontsize=12, fontweight='bold')
            ax.set_title(f'{leg.title()} Leg - Event Validation (Pressure + Detected Events)',
                        fontsize=14, fontweight='bold')
            ax.grid(True, alpha=0.3)

            # Legend (show only unique labels)
            handles, labels = ax.get_legend_handles_labels()
            by_label = dict(zip(labels, handles))
            ax.legend(by_label.values(), by_label.keys(), loc='upper right', fontsize=10)

            plt.tight_layout()

            # Save plot
            plot_path = debug_dir / f'event_validation_{leg}.png'
            plt.savefig(plot_path, dpi=150, bbox_inches='tight')
            plt.close()

            print(f"    Saved: {plot_path.name}")


# ============================================================================
# COMMAND LINE INTERFACE
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description='Smart Insole Gait Analysis - Anatomically grounded phase detection'
    )

    parser.add_argument(
        '--input',
        type=str,
        required=True,
        help='Path to input CSV file with insole data'
    )

    parser.add_argument(
        '--output',
        type=str,
        required=True,
        help='Output directory for results'
    )

    parser.add_argument(
        '--sampling-rate',
        type=float,
        default=100.0,
        help='Sampling rate in Hz (default: 100)'
    )

    args = parser.parse_args()

    # Create configuration
    config = InsoleConfig(sampling_rate=args.sampling_rate)

    # Create pipeline
    pipeline = InsolePipeline(config)

    # Run analysis
    input_path = Path(args.input)
    output_path = Path(args.output)

    pipeline.analyze_insole_data(input_path, output_path)


if __name__ == '__main__':
    main()
