#!/usr/bin/env python3
"""
Enhanced Cyclogram Visualization Module

Comprehensive gait and stride visualization suite for smart insole IMU data.
Generates 6 plot sets with 24 total subplots for biomechanical analysis.

Author: Gait Analysis Pipeline
Date: 2025-10-16
"""

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from pathlib import Path
from typing import List, Tuple, Dict, Optional
from dataclasses import dataclass
import warnings
warnings.filterwarnings('ignore')


@dataclass
class PlotConfig:
    """
    Standardized configuration for enhanced plotting.

    Dimensions: 12x6 inches (default), enforced across all plot sets
    Color Scheme: Left=Blue, Right=Red (consistent bilateral representation)
    """
    dpi: int = 150
    figure_width: float = 12.0       # Standardized to 12 inches
    figure_height: float = 6.0       # Standardized to 6 inches
    linewidth_individual: float = 0.8
    linewidth_mean: float = 3.0
    alpha_individual: float = 0.3
    alpha_mean: float = 1.0
    alpha_ci: float = 0.2            # Confidence interval shading
    marker_size_ic: int = 10
    marker_size_to: int = 8

    # Standardized color scheme
    left_color: str = '#2E86C1'      # Blue for left leg
    right_color: str = '#E74C3C'     # Red for right leg
    left_color_light: str = '#AED6F1'  # Light blue for left individual cycles
    right_color_light: str = '#F5B7B1'  # Light red for right individual cycles


class PhaseVisualizer:
    """Phase segmentation markers and visual elements for gait analysis."""

    def __init__(self):
        # Phase colors (consistent with main visualizer)
        self.stance_colors = ['#08519c', '#3182bd', '#6baed6', '#9ecae1', '#c6dbef']
        self.swing_colors = ['#a50f15', '#de2d26', '#fc9272']
        self.phase_colors = self.stance_colors + self.swing_colors

        # Phase names
        self.phase_names = [
            'IC', 'LR', 'MSt', 'TSt', 'PSw', 'ISw', 'MSw', 'TSw'
        ]

    def add_phase_markers(self, ax, x_data, y_data, phase_indices, phase_labels):
        """Add phase segmentation markers to 2D plot."""
        phase_indices_with_end = phase_indices + [len(x_data)]

        for i in range(len(phase_indices)):
            start_idx = phase_indices[i]
            end_idx = phase_indices_with_end[i + 1]

            if end_idx > len(x_data):
                end_idx = len(x_data)

            color = self.phase_colors[i % len(self.phase_colors)]

            # Plot phase segment
            ax.plot(x_data[start_idx:end_idx], y_data[start_idx:end_idx],
                   color=color, linewidth=2, alpha=0.8)

    def add_3d_phase_markers(self, ax, x_data, y_data, z_data, phase_indices):
        """Add phase segmentation markers to 3D plot."""
        phase_indices_with_end = phase_indices + [len(x_data)]

        for i in range(len(phase_indices)):
            start_idx = phase_indices[i]
            end_idx = phase_indices_with_end[i + 1]

            if end_idx > len(x_data):
                end_idx = len(x_data)

            color = self.phase_colors[i % len(self.phase_colors)]

            # Plot 3D phase segment
            ax.plot(x_data[start_idx:end_idx],
                   y_data[start_idx:end_idx],
                   z_data[start_idx:end_idx],
                   color=color, linewidth=2, alpha=0.8)


class CyclogramPlotter:
    """Modular cyclogram plotting engine for 2D and 3D visualizations."""

    def __init__(self, config: PlotConfig):
        self.config = config
        self.phase_viz = PhaseVisualizer()

    def plot_2d_cyclograms_grid(self, cycles_left, cycles_right, df, leg_prefix,
                                axis_combinations, sensor_type, output_path, title):
        """
        Generate 2×3 grid of 2D cyclograms for left and right legs.

        Args:
            cycles_left: List of left leg GaitCycle objects
            cycles_right: List of right leg GaitCycle objects
            df: DataFrame with filtered sensor data
            leg_prefix: 'L' or 'R'
            axis_combinations: List of (x_axis, y_axis, x_label, y_label) tuples
            sensor_type: 'GYRO' or 'ACC'
            output_path: Path to save figure
            title: Plot title
        """
        fig, axes = plt.subplots(2, 3, figsize=(self.config.figure_width, self.config.figure_height),
                                dpi=self.config.dpi)

        # Left leg (top row)
        for i, (x_axis, y_axis, x_label, y_label) in enumerate(axis_combinations):
            ax = axes[0, i]
            self._plot_single_2d_cyclogram(
                ax, cycles_left, df, 'L', x_axis, y_axis, x_label, y_label, 'Left'
            )

        # Right leg (bottom row)
        for i, (x_axis, y_axis, x_label, y_label) in enumerate(axis_combinations):
            ax = axes[1, i]
            self._plot_single_2d_cyclogram(
                ax, cycles_right, df, 'R', x_axis, y_axis, x_label, y_label, 'Right'
            )

        fig.suptitle(title, fontsize=16, fontweight='bold', y=0.995)
        plt.tight_layout(rect=[0, 0, 1, 0.99])
        plt.savefig(output_path, dpi=self.config.dpi, bbox_inches='tight')
        plt.close()

        print(f"  Saved: {output_path.name}")

    def _plot_single_2d_cyclogram(self, ax, cycles, df, leg_prefix, x_axis, y_axis,
                                  x_label, y_label, leg_name):
        """Plot single 2D cyclogram with all cycles and mean."""

        all_x = []
        all_y = []

        # Plot individual cycles
        for cycle in cycles:
            start_idx = cycle.phases[0].start_idx
            end_idx = cycle.phases[-1].end_idx

            cycle_data = df.iloc[start_idx:end_idx]

            x_col = f'{leg_prefix}_{x_axis}_filt'
            y_col = f'{leg_prefix}_{y_axis}_filt'

            if x_col not in cycle_data.columns or y_col not in cycle_data.columns:
                continue

            x_data = cycle_data[x_col].values
            y_data = cycle_data[y_col].values

            if len(x_data) < 2:
                continue

            # Normalize to 100 points
            normalized_len = 100
            time_original = np.linspace(0, 100, len(x_data))
            time_normalized = np.linspace(0, 100, normalized_len)

            from scipy.interpolate import interp1d
            x_interp = interp1d(time_original, x_data, kind='cubic', fill_value='extrapolate')
            y_interp = interp1d(time_original, y_data, kind='cubic', fill_value='extrapolate')

            x_norm = x_interp(time_normalized)
            y_norm = y_interp(time_normalized)

            all_x.append(x_norm)
            all_y.append(y_norm)

            # Determine color based on leg
            cycle_color = self.config.left_color_light if leg_prefix == 'L' else self.config.right_color_light

            # Plot individual cycle
            ax.plot(x_norm, y_norm, color=cycle_color,
                   linewidth=self.config.linewidth_individual,
                   alpha=self.config.alpha_individual)

        if not all_x:
            ax.text(0.5, 0.5, 'No valid cycles', ha='center', va='center',
                   transform=ax.transAxes)
            return

        # Compute mean and std
        all_x = np.array(all_x)
        all_y = np.array(all_y)

        mean_x = np.mean(all_x, axis=0)
        mean_y = np.mean(all_y, axis=0)
        std_x = np.std(all_x, axis=0)
        std_y = np.std(all_y, axis=0)

        # Determine mean color based on leg
        mean_color = self.config.left_color if leg_prefix == 'L' else self.config.right_color

        # Plot confidence interval shading
        ax.fill_between(mean_x - std_x, mean_y - std_y, mean_y + std_y,
                       color=mean_color, alpha=self.config.alpha_ci, label='±1 SD')

        # Plot mean trajectory
        ax.plot(mean_x, mean_y, color=mean_color, linewidth=self.config.linewidth_mean,
               label=f'Mean (n={len(cycles)})', alpha=self.config.alpha_mean)

        # Mark start/end
        ax.plot(mean_x[0], mean_y[0], 'go', markersize=self.config.marker_size_ic,
               label='IC (Start)', zorder=5)
        ax.plot(mean_x[-1], mean_y[-1], 'rs', markersize=self.config.marker_size_to,
               label='IC (End)', zorder=5)

        # Formatting
        ax.set_xlabel(f'{x_label} (deg/s)' if 'GYRO' in x_axis else f'{x_label} (m/s²)',
                     fontsize=10, fontweight='bold')
        ax.set_ylabel(f'{y_label} (deg/s)' if 'GYRO' in y_axis else f'{y_label} (m/s²)',
                     fontsize=10, fontweight='bold')
        ax.set_title(f'{leg_name} Leg', fontsize=12, fontweight='bold')
        ax.legend(loc='best', fontsize=8)
        ax.grid(True, alpha=0.3)
        ax.set_aspect('equal', adjustable='box')

    def plot_3d_cyclograms(self, cycles_left, cycles_right, df, sensor_type, output_path, title):
        """
        Generate 1×4 grid of 3D cyclograms (Gyro and ACC for left and right).

        Args:
            cycles_left: List of left leg GaitCycle objects
            cycles_right: List of right leg GaitCycle objects
            df: DataFrame with filtered sensor data
            sensor_type: 'GYRO' or 'ACC'
            output_path: Path to save figure
            title: Plot title
        """
        fig = plt.figure(figsize=(self.config.figure_width, self.config.figure_height), dpi=self.config.dpi)

        # Left Gyro (subplot 1)
        ax1 = fig.add_subplot(2, 2, 1, projection='3d')
        self._plot_single_3d_cyclogram(ax1, cycles_left, df, 'L', 'GYRO', 'Left GYRO')

        # Left ACC (subplot 2)
        ax2 = fig.add_subplot(2, 2, 2, projection='3d')
        self._plot_single_3d_cyclogram(ax2, cycles_left, df, 'L', 'ACC', 'Left ACC')

        # Right GYRO (subplot 3)
        ax3 = fig.add_subplot(2, 2, 3, projection='3d')
        self._plot_single_3d_cyclogram(ax3, cycles_right, df, 'R', 'GYRO', 'Right GYRO')

        # Right ACC (subplot 4)
        ax4 = fig.add_subplot(2, 2, 4, projection='3d')
        self._plot_single_3d_cyclogram(ax4, cycles_right, df, 'R', 'ACC', 'Right ACC')

        fig.suptitle(title, fontsize=16, fontweight='bold', y=0.995)
        plt.tight_layout(rect=[0, 0, 1, 0.99])
        plt.savefig(output_path, dpi=self.config.dpi, bbox_inches='tight')
        plt.close()

        print(f"  Saved: {output_path.name}")

    def _plot_single_3d_cyclogram(self, ax, cycles, df, leg_prefix, sensor_type, title):
        """Plot single 3D cyclogram with all cycles and mean."""

        all_x = []
        all_y = []
        all_z = []

        # Plot individual cycles
        for cycle in cycles:
            start_idx = cycle.phases[0].start_idx
            end_idx = cycle.phases[-1].end_idx

            cycle_data = df.iloc[start_idx:end_idx]

            x_col = f'{leg_prefix}_{sensor_type}_X_filt'
            y_col = f'{leg_prefix}_{sensor_type}_Y_filt'
            z_col = f'{leg_prefix}_{sensor_type}_Z_filt'

            if x_col not in cycle_data.columns:
                continue

            x_data = cycle_data[x_col].values
            y_data = cycle_data[y_col].values
            z_data = cycle_data[z_col].values

            if len(x_data) < 2:
                continue

            # Normalize to 100 points
            normalized_len = 100
            time_original = np.linspace(0, 100, len(x_data))
            time_normalized = np.linspace(0, 100, normalized_len)

            from scipy.interpolate import interp1d
            x_interp = interp1d(time_original, x_data, kind='cubic', fill_value='extrapolate')
            y_interp = interp1d(time_original, y_data, kind='cubic', fill_value='extrapolate')
            z_interp = interp1d(time_original, z_data, kind='cubic', fill_value='extrapolate')

            x_norm = x_interp(time_normalized)
            y_norm = y_interp(time_normalized)
            z_norm = z_interp(time_normalized)

            all_x.append(x_norm)
            all_y.append(y_norm)
            all_z.append(z_norm)

            # Determine color based on leg
            cycle_color = self.config.left_color_light if leg_prefix == 'L' else self.config.right_color_light

            # Plot individual cycle
            ax.plot(x_norm, y_norm, z_norm, color=cycle_color,
                   linewidth=self.config.linewidth_individual,
                   alpha=self.config.alpha_individual)

        if not all_x:
            ax.text2D(0.5, 0.5, 'No valid cycles', ha='center', va='center',
                     transform=ax.transAxes)
            return

        # Compute mean
        all_x = np.array(all_x)
        all_y = np.array(all_y)
        all_z = np.array(all_z)

        mean_x = np.mean(all_x, axis=0)
        mean_y = np.mean(all_y, axis=0)
        mean_z = np.mean(all_z, axis=0)

        # Determine mean color based on leg
        mean_color = self.config.left_color if leg_prefix == 'L' else self.config.right_color

        # Plot mean trajectory
        ax.plot(mean_x, mean_y, mean_z, color=mean_color,
               linewidth=self.config.linewidth_mean,
               label=f'Mean (n={len(cycles)})', alpha=self.config.alpha_mean)

        # Mark start/end
        ax.scatter(mean_x[0], mean_y[0], mean_z[0], c='green',
                  s=100, marker='o', label='IC (Start)', zorder=5)
        ax.scatter(mean_x[-1], mean_y[-1], mean_z[-1], c='red',
                  s=80, marker='s', label='IC (End)', zorder=5)

        # Formatting
        unit = '(deg/s)' if sensor_type == 'GYRO' else '(m/s²)'
        ax.set_xlabel(f'X {unit}', fontsize=10, fontweight='bold')
        ax.set_ylabel(f'Y {unit}', fontsize=10, fontweight='bold')
        ax.set_zlabel(f'Z {unit}', fontsize=10, fontweight='bold')
        ax.set_title(title, fontsize=12, fontweight='bold')
        ax.legend(loc='best', fontsize=8)
        ax.grid(True, alpha=0.3)


class GaitTimelinePlotter:
    """Temporal gait-phase timeline visualization for complete trial overview."""

    def __init__(self, config: PlotConfig):
        self.config = config
        self.phase_viz = PhaseVisualizer()

    def plot_gait_timeline(self, left_cycles, right_cycles, df, output_path):
        """
        Generate comprehensive gait-phase timeline showing all events and phases.

        Args:
            left_cycles: List of left leg GaitCycle objects
            right_cycles: List of right leg GaitCycle objects
            df: DataFrame with sensor data
            output_path: Path to save figure
        """
        fig, (ax_left, ax_right) = plt.subplots(2, 1, figsize=(self.config.figure_width, self.config.figure_height),
                                                dpi=self.config.dpi, sharex=True)

        # Plot left leg timeline
        self._plot_single_leg_timeline(ax_left, left_cycles, df, 'left', 'Left Leg')

        # Plot right leg timeline
        self._plot_single_leg_timeline(ax_right, right_cycles, df, 'right', 'Right Leg')

        # Shared x-axis label
        ax_right.set_xlabel('Time (seconds)', fontsize=12, fontweight='bold')

        fig.suptitle('Plot Set 7: Complete Gait-Phase Timeline (Full Trial Overview)',
                    fontsize=16, fontweight='bold', y=0.995)
        plt.tight_layout(rect=[0, 0, 1, 0.99])
        plt.savefig(output_path, dpi=self.config.dpi, bbox_inches='tight')
        plt.close()

        print(f"  Saved: {output_path.name}")

    def _plot_single_leg_timeline(self, ax, cycles, df, leg, title):
        """Plot timeline for single leg with phase segmentation."""

        if not cycles:
            ax.text(0.5, 0.5, f'No {leg} leg cycles detected',
                   ha='center', va='center', transform=ax.transAxes, fontsize=14)
            ax.set_title(title, fontsize=14, fontweight='bold')
            return

        # Get pressure signal for visualization
        pressure_col = f'{leg}_pressure_total'
        if pressure_col not in df.columns:
            ax.text(0.5, 0.5, 'Pressure data not available',
                   ha='center', va='center', transform=ax.transAxes, fontsize=14)
            return

        timestamps = df['timestamp'].values
        pressure = df[pressure_col].values

        # Normalize pressure for visualization
        pressure_norm = (pressure - pressure.min()) / (pressure.max() - pressure.min() + 1e-6)

        # Plot pressure signal as background
        ax.plot(timestamps, pressure_norm, color='lightgray', linewidth=1, alpha=0.5,
               label='Pressure (normalized)')

        # Plot phase-colored segments for each cycle
        for cycle in cycles:
            for phase in cycle.phases:
                # Get phase data
                phase_start_time = phase.start_time
                phase_end_time = phase.end_time

                # Find indices in dataframe
                start_mask = (df['timestamp'] >= phase_start_time) & \
                            (df['timestamp'] <= phase_end_time)

                if not start_mask.any():
                    continue

                phase_times = df.loc[start_mask, 'timestamp'].values
                phase_pressure = pressure_norm[start_mask]

                # Get phase color
                phase_num = phase.phase_number - 1  # 0-indexed
                color = self.phase_viz.phase_colors[phase_num % len(self.phase_viz.phase_colors)]

                # Plot phase segment
                ax.plot(phase_times, phase_pressure, color=color,
                       linewidth=2, alpha=0.8)

                # Add phase label at midpoint (for first occurrence)
                if cycle.cycle_id == 1:
                    mid_time = (phase_start_time + phase_end_time) / 2
                    mid_idx = np.argmin(np.abs(phase_times - mid_time))
                    if mid_idx < len(phase_pressure):
                        ax.text(mid_time, phase_pressure[mid_idx] + 0.05,
                               self.phase_viz.phase_names[phase_num],
                               fontsize=8, ha='center', rotation=0,
                               bbox=dict(boxstyle='round,pad=0.3', facecolor=color, alpha=0.3))

            # Mark cycle boundaries
            ax.axvline(cycle.start_time, color='green', linestyle='--',
                      linewidth=1.5, alpha=0.6, label='IC' if cycle.cycle_id == 1 else '')

        # Add stride index annotations
        for i, cycle in enumerate(cycles[:min(5, len(cycles))], 1):  # First 5 cycles
            mid_time = (cycle.start_time + cycle.end_time) / 2
            ax.text(mid_time, 1.05, f'C{i}', fontsize=10, ha='center',
                   fontweight='bold', color='black')

        # Formatting
        ax.set_ylabel('Normalized Gait State', fontsize=11, fontweight='bold')
        ax.set_title(f'{title} (n={len(cycles)} cycles)', fontsize=14, fontweight='bold')
        ax.set_ylim(-0.1, 1.2)
        ax.grid(True, alpha=0.3, axis='x')

        # Legend (show only unique labels)
        handles, labels = ax.get_legend_handles_labels()
        by_label = dict(zip(labels, handles))
        ax.legend(by_label.values(), by_label.keys(), loc='upper right', fontsize=8)


class EnhancedInsoleVisualizer:
    """
    Comprehensive visualization suite for smart insole gait analysis.

    Generates 7 plot sets:
    - Plot Set 1: Gyroscopic Cyclogram Stride Analysis (6 subplots)
    - Plot Set 2: Accelerometer Cyclogram Stride Analysis (6 subplots)
    - Plot Set 3: 3D Cyclogram Stride Analysis (4 subplots)
    - Plot Set 4: Gyroscopic Cyclogram Gait Analysis (6 subplots)
    - Plot Set 5: Accelerometer Cyclogram Gait Analysis (6 subplots)
    - Plot Set 6: 3D Cyclogram Gait Analysis (2 subplots)
    - Plot Set 7: Complete Gait-Phase Timeline (2 subplots)
    """

    def __init__(self, config: PlotConfig):
        self.config = config
        self.plotter = CyclogramPlotter(config)
        self.timeline_plotter = GaitTimelinePlotter(config)
        self.phase_viz = PhaseVisualizer()

    def generate_all_plot_sets(self, left_cycles, right_cycles, df, output_dir: Path):
        """
        Generate all 7 plot sets for comprehensive gait analysis.

        Args:
            left_cycles: List of left leg GaitCycle objects
            right_cycles: List of right leg GaitCycle objects
            df: DataFrame with processed sensor data
            output_dir: Directory to save plots
        """
        print("\n" + "="*70)
        print("GENERATING COMPREHENSIVE VISUALIZATION SUITE (7 PLOT SETS)")
        print("="*70)

        plots_dir = output_dir / "plots"
        plots_dir.mkdir(parents=True, exist_ok=True)

        # Plot Set 1: Gyroscopic Cyclogram Stride Analysis
        print("\n📊 Plot Set 1: Gyroscopic Cyclogram Stride Analysis...")
        gyro_combinations = [
            ('GYRO_X', 'GYRO_Y', 'Gyro X', 'Gyro Y'),
            ('GYRO_X', 'GYRO_Z', 'Gyro X', 'Gyro Z'),
            ('GYRO_Y', 'GYRO_Z', 'Gyro Y', 'Gyro Z')
        ]

        self.plotter.plot_2d_cyclograms_grid(
            left_cycles, right_cycles, df, 'L',
            gyro_combinations, 'GYRO',
            plots_dir / 'plot_set_1_gyro_stride_analysis.png',
            'Plot Set 1: Gyroscopic Cyclogram Stride Analysis (All Cycles + Mean)'
        )

        # Plot Set 2: Accelerometer Cyclogram Stride Analysis
        print("\n📊 Plot Set 2: Accelerometer Cyclogram Stride Analysis...")
        acc_combinations = [
            ('ACC_X', 'ACC_Y', 'ACC X', 'ACC Y'),
            ('ACC_X', 'ACC_Z', 'ACC X', 'ACC Z'),
            ('ACC_Y', 'ACC_Z', 'ACC Y', 'ACC Z')
        ]

        self.plotter.plot_2d_cyclograms_grid(
            left_cycles, right_cycles, df, 'L',
            acc_combinations, 'ACC',
            plots_dir / 'plot_set_2_acc_stride_analysis.png',
            'Plot Set 2: Accelerometer Cyclogram Stride Analysis (All Cycles + Mean)'
        )

        # Plot Set 3: 3D Cyclogram Stride Analysis
        print("\n📊 Plot Set 3: 3D Cyclogram Stride Analysis...")
        self.plotter.plot_3d_cyclograms(
            left_cycles, right_cycles, df, 'BOTH',
            plots_dir / 'plot_set_3_3d_stride_analysis.png',
            'Plot Set 3: 3D Cyclogram Stride Analysis (Gyro + ACC, All Cycles + Mean)'
        )

        # Plot Set 4: Gyroscopic Cyclogram Gait Analysis
        print("\n📊 Plot Set 4: Gyroscopic Cyclogram Gait Analysis...")
        self.plotter.plot_2d_cyclograms_grid(
            left_cycles, right_cycles, df, 'L',
            gyro_combinations, 'GYRO',
            plots_dir / 'plot_set_4_gyro_gait_analysis.png',
            'Plot Set 4: Gyroscopic Cyclogram Gait Analysis (Full Gait Cycles + Mean)'
        )

        # Plot Set 5: Accelerometer Cyclogram Gait Analysis
        print("\n📊 Plot Set 5: Accelerometer Cyclogram Gait Analysis...")
        self.plotter.plot_2d_cyclograms_grid(
            left_cycles, right_cycles, df, 'L',
            acc_combinations, 'ACC',
            plots_dir / 'plot_set_5_acc_gait_analysis.png',
            'Plot Set 5: Accelerometer Cyclogram Gait Analysis (Full Gait Cycles + Mean)'
        )

        # Plot Set 6: 3D Cyclogram Gait Analysis
        print("\n📊 Plot Set 6: 3D Cyclogram Gait Analysis...")
        self.plot_set_6_3d_gait_analysis(left_cycles, right_cycles, df, plots_dir)

        # Plot Set 7: Complete Gait-Phase Timeline
        print("\n📊 Plot Set 7: Complete Gait-Phase Timeline...")
        self.timeline_plotter.plot_gait_timeline(
            left_cycles, right_cycles, df,
            plots_dir / 'plot_set_7_gait_timeline_full.png'
        )

        print("\n" + "="*70)
        print("✅ VISUALIZATION SUITE COMPLETE")
        print(f"   Generated 7 comprehensive plot sets")
        print(f"   Output directory: {plots_dir}")
        print("="*70)

    def plot_set_6_3d_gait_analysis(self, left_cycles, right_cycles, df, plots_dir):
        """
        Plot Set 6: 3D Cyclogram Gait Analysis (2 subplots: Gyro and ACC).
        """
        fig = plt.figure(figsize=(self.config.figure_width, self.config.figure_height), dpi=self.config.dpi)

        # Subplot 1: 3D Gyroscopic Cyclogram
        ax1 = fig.add_subplot(1, 2, 1, projection='3d')
        self._plot_bilateral_3d_cyclogram(ax1, left_cycles, right_cycles, df, 'GYRO',
                                         '3D Gyroscopic Cyclogram (Left + Right)')

        # Subplot 2: 3D Accelerometer Cyclogram
        ax2 = fig.add_subplot(1, 2, 2, projection='3d')
        self._plot_bilateral_3d_cyclogram(ax2, left_cycles, right_cycles, df, 'ACC',
                                         '3D Accelerometer Cyclogram (Left + Right)')

        fig.suptitle('Plot Set 6: 3D Cyclogram Gait Analysis (Full Cycles + Mean)',
                    fontsize=16, fontweight='bold', y=0.98)
        plt.tight_layout(rect=[0, 0, 1, 0.97])

        output_path = plots_dir / 'plot_set_6_3d_gait_analysis.png'
        plt.savefig(output_path, dpi=self.config.dpi, bbox_inches='tight')
        plt.close()

        print(f"  Saved: {output_path.name}")

    def _plot_bilateral_3d_cyclogram(self, ax, left_cycles, right_cycles, df, sensor_type, title):
        """Plot bilateral 3D cyclogram with left and right legs."""

        # Left leg (blue)
        all_x_left, all_y_left, all_z_left = [], [], []
        for cycle in left_cycles:
            start_idx = cycle.phases[0].start_idx
            end_idx = cycle.phases[-1].end_idx
            cycle_data = df.iloc[start_idx:end_idx]

            x_col = f'L_{sensor_type}_X_filt'
            y_col = f'L_{sensor_type}_Y_filt'
            z_col = f'L_{sensor_type}_Z_filt'

            if x_col not in cycle_data.columns:
                continue

            x_data = cycle_data[x_col].values
            y_data = cycle_data[y_col].values
            z_data = cycle_data[z_col].values

            if len(x_data) >= 2:
                # Normalize
                from scipy.interpolate import interp1d
                normalized_len = 100
                time_original = np.linspace(0, 100, len(x_data))
                time_normalized = np.linspace(0, 100, normalized_len)

                x_norm = interp1d(time_original, x_data, kind='cubic', fill_value='extrapolate')(time_normalized)
                y_norm = interp1d(time_original, y_data, kind='cubic', fill_value='extrapolate')(time_normalized)
                z_norm = interp1d(time_original, z_data, kind='cubic', fill_value='extrapolate')(time_normalized)

                all_x_left.append(x_norm)
                all_y_left.append(y_norm)
                all_z_left.append(z_norm)

                ax.plot(x_norm, y_norm, z_norm, color=self.config.left_color_light,
                       linewidth=0.8, alpha=0.3)

        # Right leg (red)
        all_x_right, all_y_right, all_z_right = [], [], []
        for cycle in right_cycles:
            start_idx = cycle.phases[0].start_idx
            end_idx = cycle.phases[-1].end_idx
            cycle_data = df.iloc[start_idx:end_idx]

            x_col = f'R_{sensor_type}_X_filt'
            y_col = f'R_{sensor_type}_Y_filt'
            z_col = f'R_{sensor_type}_Z_filt'

            if x_col not in cycle_data.columns:
                continue

            x_data = cycle_data[x_col].values
            y_data = cycle_data[y_col].values
            z_data = cycle_data[z_col].values

            if len(x_data) >= 2:
                from scipy.interpolate import interp1d
                normalized_len = 100
                time_original = np.linspace(0, 100, len(x_data))
                time_normalized = np.linspace(0, 100, normalized_len)

                x_norm = interp1d(time_original, x_data, kind='cubic', fill_value='extrapolate')(time_normalized)
                y_norm = interp1d(time_original, y_data, kind='cubic', fill_value='extrapolate')(time_normalized)
                z_norm = interp1d(time_original, z_data, kind='cubic', fill_value='extrapolate')(time_normalized)

                all_x_right.append(x_norm)
                all_y_right.append(y_norm)
                all_z_right.append(z_norm)

                ax.plot(x_norm, y_norm, z_norm, color=self.config.right_color_light,
                       linewidth=0.8, alpha=0.3)

        # Plot mean trajectories
        if all_x_left:
            mean_x_left = np.mean(all_x_left, axis=0)
            mean_y_left = np.mean(all_y_left, axis=0)
            mean_z_left = np.mean(all_z_left, axis=0)

            ax.plot(mean_x_left, mean_y_left, mean_z_left, color=self.config.left_color,
                   linewidth=3, label=f'Left Mean (n={len(left_cycles)})', alpha=1.0)

            ax.scatter(mean_x_left[0], mean_y_left[0], mean_z_left[0],
                      c='green', s=100, marker='o', label='Left IC', zorder=5)

        if all_x_right:
            mean_x_right = np.mean(all_x_right, axis=0)
            mean_y_right = np.mean(all_y_right, axis=0)
            mean_z_right = np.mean(all_z_right, axis=0)

            ax.plot(mean_x_right, mean_y_right, mean_z_right, color=self.config.right_color,
                   linewidth=3, label=f'Right Mean (n={len(right_cycles)})', alpha=1.0)

            ax.scatter(mean_x_right[0], mean_y_right[0], mean_z_right[0],
                      c='orange', s=100, marker='o', label='Right IC', zorder=5)

        # Formatting
        unit = '(deg/s)' if sensor_type == 'GYRO' else '(m/s²)'
        ax.set_xlabel(f'X {unit}', fontsize=10, fontweight='bold')
        ax.set_ylabel(f'Y {unit}', fontsize=10, fontweight='bold')
        ax.set_zlabel(f'Z {unit}', fontsize=10, fontweight='bold')
        ax.set_title(title, fontsize=12, fontweight='bold')
        ax.legend(loc='best', fontsize=8)
        ax.grid(True, alpha=0.3)
